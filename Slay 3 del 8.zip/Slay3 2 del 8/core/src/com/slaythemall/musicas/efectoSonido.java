package com.slaythemall.musicas;

import com.slaythemall.utiles.Recursos;

public abstract class efectoSonido {

	public static final Musica EFECTO_SALTO = new Musica(Recursos.EFECTO_SONIDO_SALTAR);
	public static final Musica EFECTO_CAMINAR = new Musica(Recursos.EFECTO_SONIDO_CAMINAR);
	public static final Musica EFECTO_DASH = new Musica(Recursos.EFECTO_SONIDO_DASH);
	public static final Musica EFECTO_ESPADA_BASICO = new Musica(Recursos.EFECTO_SONIDO_ESPADA_BASICO);
    

	//para liberar recursos
    public static void dispose() {
        EFECTO_SALTO.dispose();
        EFECTO_CAMINAR.dispose();
        EFECTO_DASH.dispose();
        EFECTO_ESPADA_BASICO.dispose();
    }
    
    public static void setVolume(float volume) {
    	EFECTO_SALTO.setVolume(volume);
    	EFECTO_CAMINAR.setVolume(volume);
    	EFECTO_DASH.setVolume(volume);
    	EFECTO_ESPADA_BASICO.setVolume(volume);
    }
}
