package com.slaythemall.musicas;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;

public class Musica{

	private Music backgroundMusic;
	private boolean isLoop = false;
	
	public Musica(String rutaCancion){
		this.backgroundMusic = Gdx.audio.newMusic(Gdx.files.internal(rutaCancion));
        // Establecer el volumen (0.0 a 1.0)
		this.backgroundMusic.setVolume(0.1f);
	}
	
	public void loopingMusic() {
		// Configurar la música para que se repita
		this.isLoop = (this.isLoop) ? false : true;
		this.backgroundMusic.setLooping(this.isLoop);
	}
	public void setVolume(float volume) {
		this.backgroundMusic.setVolume(volume);
	}

	public void playMusic() {
        if (backgroundMusic != null) {
            backgroundMusic.play();
        }
    }

    public void stopMusic() {
        if (this.backgroundMusic != null) {
        	this.backgroundMusic.stop();
        }
    }
	
	public void dispose() {
		if (this.backgroundMusic != null) {
			this.backgroundMusic.dispose();
        }
	}
}
