package com.slaythemall.objetos;

import static com.slaythemall.utiles.Constantes.PPM;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.slaythemall.animaciones.AnimacionJugador;
import com.slaythemall.io.Entradas;
import com.slaythemall.musicas.efectoSonido;
import com.slaythemall.utiles.Recursos;

public class Jugador extends GameEntity {
    private EstadoJugador estadoJugador;
    private AnimacionJugador animacionJugador;
    private TextureAtlas atlas;
    private float stateTime;
    private int contadorSalto;
    private boolean isFacingRight;
    private Entradas entradas;
    private boolean tocandoSuelo;
    private boolean puedeDobleSalto;
    private boolean isDashing;
    private float dashSpeed;
    private float dashTime;
    private float dashDuration;
    private int dashCount;
    private final int maxDashes = 2;
    private float dashCooldown;
    private final float dashCooldownDuration = 0.5f; // Duración del tiempo de enfriamiento en segundos
    private float dashBufferTime;
    private final float dashBufferDuration = 0.5f; // Tiempo permitido para realizar el segundo dash
    private boolean hasDashedInAir;
    private boolean isAttacking;
    private int attackCount;
    private float attackCooldown;
    private final float attackCooldownDuration = 0.5f; // Duración del cooldown en segundos
    private float attackBufferTime;
    private final float attackBufferDuration = 0.5f; // Tiempo permitido para el buffer de ataque
    private boolean attackRequested; // Para manejar la solicitud de ataque
    private float attackTime; // Tiempo que ha pasado desde que comenzó el ataque
    private float attackDuration;
    private float comboResetTime; // Tiempo para resetear el combo si no se realiza el siguiente ataque
    private float timeSinceLastAttack; // Tiempo desde el último ataque
    private Enemigo enemyContact;
    private float timeSinceLastHit;
    private final float hitInterval = 0.6f; // Intervalo de tiempo permitido entre golpes
    private Fixture sensorEspada;
    private float espadaWidth;
    private float espadaHeight;

    public Jugador(float ancho, float alto, Body body) {
        super(ancho, alto, body);
        this.velocidad = 10f;
        this.dashSpeed = 1.9f; // La velocidad del dash
        this.dashDuration = 0.4f; // La duración del dash en segundos
        this.isDashing = false;
        this.contadorSalto = 0;
        this.dashCount = 0;
        this.dashCooldown = 0;
        this.dashBufferTime = 0;
        this.hasDashedInAir = false;
        this.atlas = new TextureAtlas(Gdx.files.internal(Recursos.ANIMACIONES_JUGADOR));
        this.estadoJugador = new EstadoJugador();
        this.animacionJugador = new AnimacionJugador(atlas);
        this.stateTime = 0f;
        this.isFacingRight = true; // Inicialmente el jugador se enfrenta a la derecha
        this.entradas = new Entradas(); // Inicializar la instancia de Entradas
        this.body = body;
        this.body.setUserData(this); // Asignar this como userData para identificar en el ContactListener
        this.tocandoSuelo = false;
        this.puedeDobleSalto = false;
        this.isAttacking = false;
        this.attackCount = 0;
        this.attackCooldown = 0;
        this.attackBufferTime = 0;
        this.attackRequested = false;
        this.attackDuration = 0.6f;
        this.attackTime = 0f;
        this.comboResetTime = 0.4f;
        this.timeSinceLastAttack = 0f;
        
        Gdx.input.setInputProcessor(entradas); // Configurar el procesador de entradas
    }

    @Override
    public void update() {
        x = body.getPosition().x * PPM;
        y = body.getPosition().y * PPM;

        verificarEntradaDeUsuario();
        estadoJugador.actualizarEstado(this);
       
  
        if (timeSinceLastHit > 0) {
            timeSinceLastHit -= Gdx.graphics.getDeltaTime();
        }

        if (attackCooldown > 0) {
            attackCooldown -= Gdx.graphics.getDeltaTime();
        }

        if (attackBufferTime > 0) {
            attackBufferTime -= Gdx.graphics.getDeltaTime();
        }

        if (isAttacking) {
            attackTime += Gdx.graphics.getDeltaTime();
            timeSinceLastAttack = 0f;

            if (attackTime >= attackDuration) {
                isAttacking = false;
                attackRequested = false;
                attackTime = 0f;

                if (attackCount >= 3) {
                    attackCooldown = attackCooldownDuration;
                    attackCount = 0;
                }
            }
        } else {
            timeSinceLastAttack += Gdx.graphics.getDeltaTime();

            if (timeSinceLastAttack >= comboResetTime) {
                attackCount = 0;
            }
        }

        if (dashCooldown > 0) {
            dashCooldown -= Gdx.graphics.getDeltaTime();
            if (dashCooldown <= 0) {
                if (tocandoSuelo) {
                    dashCount = 0;
                } else {
                    dashBufferTime = dashBufferDuration;
                }
            }
        }

        if (dashBufferTime > 0) {
            dashBufferTime -= Gdx.graphics.getDeltaTime();
            if (dashBufferTime <= 0 && dashCount < maxDashes) {
                dashCooldown = dashCooldownDuration;
            }
        }

        if (isAttacking) {
        	efectoSonido.EFECTO_ESPADA_BASICO.playMusic();
		}
        if (isAttacking() && enemyContact != null && timeSinceLastHit <= 0) {
            enemyContact.recibirGolpe();
            timeSinceLastHit = hitInterval; // Reiniciar el tiempo desde el último golpe
        }
        // Manejo del cooldown y buffer para el dash
        if (dashCooldown > 0) {
            dashCooldown -= Gdx.graphics.getDeltaTime();
            if (dashCooldown <= 0) {
                if (tocandoSuelo) {
                    dashCount = 0; // Resetear el contador de dashes después del tiempo de enfriamiento solo si está en el suelo
                } else {
                    // Restablecer el tiempo de buffer para permitir un segundo dash en el aire
                    dashBufferTime = dashBufferDuration;
                }
            }
        }

        if (dashBufferTime > 0) {
            dashBufferTime -= Gdx.graphics.getDeltaTime();
            if (dashBufferTime <= 0 && dashCount < maxDashes) {
                // Si el tiempo para el segundo dash se acaba, activar el cooldown
                dashCooldown = dashCooldownDuration;
            }
        }
      
       
        
      
    }

    @Override
    public void render(SpriteBatch batch) {
        TextureRegion currentFrame = animacionJugador.getFrame(estadoJugador.getEstadoActual(), Gdx.graphics.getDeltaTime());
        float offSetXDerecha = 4;
        float offSetIzquierda = (offSetXDerecha * 7);
        float offSetWidth = 11;
        if (currentFrame != null) {
            if (!isFacingRight) {
                // Si el sprite está mirando hacia la izquierda, dibujarlo en negativo
                batch.draw(currentFrame, x - ancho + offSetIzquierda / 2 + ancho, y - alto / 2, -ancho - offSetWidth, alto); // el offset de la izquierda es 7 veces más que el de la derecha porque al girar el sprite cambia el punto de origen
            } else {
                // Si el sprite está mirando hacia la derecha, dibujarlo normalmente
                batch.draw(currentFrame, x - ancho + offSetXDerecha / 2, y - alto / 2, ancho + offSetWidth, alto);
            }
        }
    }

    public void setTocandoSuelo(boolean tocandoSuelo) {
        this.tocandoSuelo = tocandoSuelo;
        if (tocandoSuelo) {
            puedeDobleSalto = true;
            contadorSalto = 0; // Reiniciar el contador de saltos al tocar el suelo
            hasDashedInAir = false; // Reiniciar la bandera de dash en el aire
            dashCount = 0; // Resetear el contador de dashes al tocar el suelo
        }
    }

    public boolean isTocandoSuelo() {
        return tocandoSuelo;
    }

    private void verificarEntradaDeUsuario() {
        velX = 0;
        
        if (entradas.isAtacar() && canAttack()) {
            attack();
            entradas.resetAtacar(); // Resetear la entrada de ataque después de usarla
        }
        

        if (isDashing) {
            dashTime += Gdx.graphics.getDeltaTime();
            if (dashTime < dashDuration) {
                velX = isFacingRight ? dashSpeed : -dashSpeed;
                body.setLinearVelocity(velX * velocidad, 0); // Establecer velocidad vertical a 0 durante el dash
                efectoSonido.EFECTO_DASH.playMusic();
            } else {
                isDashing = false;
            }
        } else {
            if (entradas.isDerecha()) {
                velX = 1;
            }
            if (entradas.isIzquierda()) {
                velX = -1;
            }
            //SOLO REPRODUCE CUANDO ESTA TOCANDO EL SUELO -> MÚSICA
            if((entradas.isDerecha() || entradas.isIzquierda())&&tocandoSuelo) {
            	efectoSonido.EFECTO_CAMINAR.playMusic();
            }
            if (entradas.isDash() && dashCount < maxDashes && dashCooldown <= 0 && !(hasDashedInAir && !tocandoSuelo)) {
                isDashing = true;
                dashTime = 0;
                dashCount++;
                dashBufferTime = dashBufferDuration; // Iniciar el buffer de tiempo para el segundo dash
                if (dashCount == maxDashes) {
                    hasDashedInAir = !tocandoSuelo; // Si alcanza el máximo de dashes, establecer hasDashedInAir si no está tocando el suelo
                    dashCooldown = dashCooldownDuration;
                }
            }
        }

        if (!isDashing && entradas.isSalto() && (isTocandoSuelo() || puedeDobleSalto) && contadorSalto < 2) {
            if (contadorSalto == 1) {
                // Para el segundo salto, establece la velocidad vertical a 0 antes de aplicar el impulso
                body.setLinearVelocity(body.getLinearVelocity().x, 0);
            }
            float fuerza = body.getMass() * 18;
            body.applyLinearImpulse(new Vector2(0, fuerza), body.getPosition(), true);
            contadorSalto++;
            if (!isTocandoSuelo()) {
                puedeDobleSalto = false;
            }
            if (isTocandoSuelo() && body.getLinearVelocity().y == 0) {
                contadorSalto = 0;
            }
            entradas.resetSalto(); // Resetear el estado de salto después de aplicarlo
            efectoSonido.EFECTO_SALTO.playMusic();
        }

        if (!isDashing) {
            body.setLinearVelocity(velX * velocidad, body.getLinearVelocity().y); // Solo actualizar la velocidad en X si no está dasheando
        }

        // Actualizar la dirección del sprite
        if (velX != 0) {
            isFacingRight = velX > 0;
        }
    }

    public boolean isJumping() {
        return body.getLinearVelocity().y > 0;
    }

    public boolean isFalling() {
        return body.getLinearVelocity().y < 0;
    }

    public boolean isWalking() {
        return getVelX() != 0;
    }

    public void resetStateTime() {
        stateTime = 0f;
    }

    public float getVelX() {
        return velX;
    }

    public boolean isDashing() {
        return isDashing;
    }
    
    public boolean isAttacking() { // Nuevo método para verificar si el jugador está atacando
        return isAttacking;
    }
    private boolean canAttack() {
        return attackCooldown <= 0 && !isAttacking;
    }

    private void attack() {
        isAttacking = true;
        attackRequested = true;
        attackCount++;
        attackBufferTime = attackBufferDuration; // Iniciar el buffer de tiempo para permitir ataques rápidos
        attackTime = 0f; // Reiniciar el tiempo del ataque
        timeSinceLastAttack = 0f; // Resetear el tiempo desde el último ataque
        // Lógica adicional para el ataque (por ejemplo, activar la animación de ataque)
    }
    public void setEnemyContact(Enemigo enemigo) {
        this.enemyContact = enemigo;
    }
    public void setSensorEspada(Fixture sensorEspada) {
        this.sensorEspada = sensorEspada;
    }
    

    public void actualizarSensorEspada() {
        if (sensorEspada != null) {
            PolygonShape shape = (PolygonShape) sensorEspada.getShape();
        
        //    sensorEspada.getBody().getPosition().x
            // Obtener dimensiones originales del Jugador
            float width = espadaWidth / 2 / PPM;
            float height = espadaHeight / 2 / PPM;

            Vector2[] vertices = new Vector2[4];
            for (int i = 0; i < vertices.length; i++) {
                vertices[i] = new Vector2();
            }

            // Calcular el offset basado en la dirección del jugador
            float offsetX = isFacingRight ? width : -width;
            float offsetY = height;

            vertices[0].set(-width + offsetX, -height + offsetY);
            vertices[1].set(width + offsetX, -height + offsetY);
            vertices[2].set(width + offsetX, height + offsetY);
            vertices[3].set(-width + offsetX, height + offsetY);

            shape.set(vertices);
        }
    }
   public void setEspadaDimensiones(float width, float height) {
       this.espadaWidth = width;
       this.espadaHeight = height;
       
   }

 
}