package com.slaythemall.animaciones;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.slaythemall.objetos.Estados;

public class AnimacionJugador extends Animacion {
    private Animation<TextureRegion> caminaAnimation;
    private Animation<TextureRegion> saltaAnimation;
    private Animation<TextureRegion> caidaAnimation;
    private Animation<TextureRegion> caidaRepeatAnimation;
    private Animation<TextureRegion> idleAnimation;
    private Animation<TextureRegion> dashAnimation;
    private Animation<TextureRegion> atacarAnimation; // Nueva animación de ataque

    public AnimacionJugador(TextureAtlas atlas) {
        super(atlas);
        caminaAnimation = createAnimation("caminar", 6, 0.1f);
        saltaAnimation = createAnimation("salto", 3, 0.1f);
        caidaAnimation = createAnimation("caida", 3, 0.1f);
        caidaRepeatAnimation = createAnimation("caida_repeticion", 2, 0.1f);
        idleAnimation = createAnimation("idle", 6, 0.1f);
        dashAnimation = createAnimation("dash", 5, 0.08f);
        atacarAnimation = createAnimation("atacarA", 6, 0.1f); 
    }

    @Override
    public TextureRegion getFrame(Estados estadoActual, float deltaTime) {
        stateTime += deltaTime;
        switch (estadoActual) {
            case SALTAR:
                return saltaAnimation.getKeyFrame(stateTime, true);
            case CAER:
                TextureRegion currentFrame = caidaAnimation.getKeyFrame(stateTime, false);
                if (caidaAnimation.isAnimationFinished(stateTime)) {
                    currentFrame = caidaRepeatAnimation.getKeyFrame(stateTime, true);
                }
                return currentFrame;
            case CAMINAR:
                return caminaAnimation.getKeyFrame(stateTime, true);
            case DASH:
                return dashAnimation.getKeyFrame(stateTime, true);
            case ATACAR: // Nuevo caso para la animación de ataque
                return atacarAnimation.getKeyFrame(stateTime, true);
            case IDLE:
            default:
                return idleAnimation.getKeyFrame(stateTime, true);
        }
    }
}
