package com.slaythemall.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
//import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.slaythemall.animaciones.AnimacionJugador;
import com.slaythemall.musicas.Musica;
import com.slaythemall.musicas.musicaAmbiente;
import com.slaythemall.pantallas.PantallaInicio;
import com.slaythemall.pantallas.PantallaJuego;
import com.slaythemall.utiles.Recursos;
import com.slaythemall.utiles.Render;

public class SlayThemAll extends Game {
    Musica musica;
    public static SlayThemAll INSTANCE;
    private AnimacionJugador animacionJugador;
    private TextureAtlas atlas;

    public SlayThemAll() {
        INSTANCE = this;
    }

    @Override
    public void create() {
        Render.app = this;
        Render.batch = new SpriteBatch();
        atlas = new TextureAtlas(Gdx.files.internal(Recursos.ANIMACIONES_JUGADOR));
        animacionJugador = new AnimacionJugador(atlas);
        
        this.setScreen(new PantallaJuego());
//        this.setScreen(new PantallaInicio());
        musicaAmbiente.AMBIENTE_PRINCIPAL.playMusic();
        musicaAmbiente.AMBIENTE_PRINCIPAL.setVolume(0);        
        musicaAmbiente.AMBIENTE_PRINCIPAL.loopingMusic();
    }

    @Override
    public void render() {
        super.render();
    }

    @Override
    public void dispose() {
        Render.batch.dispose();
        if (animacionJugador != null) {
            animacionJugador.dispose();
        }
    }
}
