package com.slaythemall.pantallas;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Slider;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.slaythemall.elementos.Imagen;
import com.slaythemall.elementos.Texto;
import com.slaythemall.io.Entradas;
import com.slaythemall.utiles.Config;
import com.slaythemall.utiles.Recursos;
import com.slaythemall.utiles.Render;

public class PantallaGameWin implements Screen {

	private Imagen fondo;
	private SpriteBatch b;
	private Stage stage;
	private Texto texto;
	Entradas entrada = new Entradas();

	public void show() {
		fondo = new Imagen(Recursos.FONDO_WIN);
		b = Render.batch;
		stage = new Stage(new ScreenViewport());
		Gdx.input.setInputProcessor(entrada);

		texto = new Texto(Recursos.FUENTE_MENU, 30, Color.YELLOW, false);
		texto.setTexto("SALIR");
		texto.setPosicion((Config.ANCHO / 2) - (texto.getAncho() / 2), Config.ALTO / 2 + 50);
	}

	@Override
	public void render(float delta) {

		// Limpiar la pantalla
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		// Dibujar el fondo
		b.begin();
			fondo.dibujar();
			texto.dibujar();
			texto.dibujar();
		b.end();

		if(entrada.isEnter()) {
			Render.app.setScreen(new PantallaMenu());
		}
	}

	@Override
	public void resize(int width, int height) {
		stage.getViewport().update(width, height, true);
	}

	@Override
	public void pause() {

	}

	@Override
	public void resume() {

	}

	@Override
	public void hide() {

	}

	@Override
	public void dispose() {
		stage.dispose();
	}

}
