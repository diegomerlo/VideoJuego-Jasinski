package com.slaythemall.pantallas;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.slaythemall.elementos.Imagen;
import com.slaythemall.elementos.Texto;
import com.slaythemall.io.Entradas;
import com.slaythemall.utiles.Config;
import com.slaythemall.utiles.Recursos;
import com.slaythemall.utiles.Render;

public class PantallaPersonajes implements Screen {

	private static int opcElegido = 0;
	private Imagen fondo, flecha, personajeJose, personajeSen, contorno, backButton;
	private SpriteBatch b;
	private Stage stage;
	private Texto textos[] = new Texto[2];
	private Entradas entrada = new Entradas();

	@Override
	public void show() {
		fondo = new Imagen(Recursos.FONDO_MENU);
		b = Render.batch;

		stage = new Stage(new ScreenViewport());

		InputMultiplexer multiplexer = new InputMultiplexer();
		multiplexer.addProcessor(stage); // Añadir el procesador del stage
		multiplexer.addProcessor(entrada); // Añadir tu procesador de entradas personal
		Gdx.input.setInputProcessor(multiplexer);

		textos[0] = new Texto(Recursos.FUENTE_MENU, 30, Color.WHITE, false);
		textos[0].setTexto("Jose-San");
		textos[0].setPosicion((Config.ANCHO / 2 - textos[0].getAncho() / 2) + (Config.ANCHO / 4),
				Config.ALTO / 2 - 150);

		textos[1] = new Texto(Recursos.FUENTE_MENU, 30, Color.WHITE, false);
		textos[1].setTexto("Sen-Ju");
		textos[1].setPosicion((Config.ANCHO / 2 - textos[0].getAncho() / 2) - (Config.ANCHO / 4),
				Config.ALTO / 2 - 150);
		
		backButton = new Imagen(Recursos.FLECHA_ATRAS);

		// Posicionar el botón en la esquina superior izquierda
		backButton.setSize(50, 50);

		flecha = new Imagen(Recursos.FLECHA_PERSONAJES);
		personajeJose = new Imagen(Recursos.PERSONAJE_JOSE);
		personajeSen = new Imagen(Recursos.PERSONAJE_JOSE);
		contorno = new Imagen(Recursos.CONTORNO_PERSONAJE_ELECCION);
		personajeJose.setSize(200, 250);
		personajeSen.setSize(200, 250);
		contorno.setSize(200, 250);
		flecha.setSize(50, 50);
	}

	@Override
	public void render(float delta) {
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		b.begin();
		fondo.dibujar();
		textos[0].dibujar();
		textos[1].dibujar();
		backButton.dibujar(20, Config.ALTO - backButton.getAlto() - 20);

		float contornoX = textos[opcElegido].getX() + 10;
		float contornoY = textos[opcElegido].getY() + 20;
		contorno.dibujar(contornoX, contornoY);
		
		personajeJose.dibujar(textos[0].getX()/*-flecha.getAncho()*/,160);
		personajeSen.dibujar(textos[1].getX()/*-flecha.getAncho()*/,160);
		

		float flechaX = textos[opcElegido].getX()-flecha.getAncho()-10;
		float flechaY = textos[opcElegido].getY()-flecha.getAlto()+5;
		flecha.dibujar(flechaX, flechaY);
		
		b.end();

		if (entrada.isEscape()) {
			Render.app.setScreen(new PantallaMenu());
		}

		if (entrada.isIzquierda()) {
			textos[opcElegido].setColor(Color.WHITE);
			if (opcElegido < textos.length - 1) {
				opcElegido++;
			} else {
				opcElegido = 0;
			}
			textos[opcElegido].setColor(Color.RED);
			entrada.resetMoverIzquierda(); // Resetear para evitar múltiples movimientos con una pulsación
		}

		if (entrada.isDerecha()) {
			textos[opcElegido].setColor(Color.WHITE);
			if (opcElegido > 0) {
				opcElegido--;
			} else {
				opcElegido = textos.length - 1;
			}
			textos[opcElegido].setColor(Color.RED);
			entrada.resetMoverDerecha(); // Resetear para evitar múltiples movimientos con una pulsación
		}

		if (entrada.isEnter()) {

			switch (opcElegido) {

			case 0:
				Render.app.setScreen(new PantallaJuego());
				break;
			case 1:
				Render.app.setScreen(new PantallaJuego());
				break;
			}
		}
		stage.act(delta);
		stage.draw();

	}

	public static int opcElegido() {
		return opcElegido;
	}
	@Override
	public void resize(int width, int height) {
		stage.getViewport().update(width, height, true);
	}

	@Override
	public void pause() {

	}

	@Override
	public void resume() {

	}

	@Override
	public void hide() {

	}

	@Override
	public void dispose() {

	}

}
