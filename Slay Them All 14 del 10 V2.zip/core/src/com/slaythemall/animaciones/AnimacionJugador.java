package com.slaythemall.animaciones;

import java.util.HashMap;
import java.util.Map;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.slaythemall.objetos.Estados;

public class AnimacionJugador extends Animacion {
	private Map<Estados, Animation<TextureRegion>> animaciones;

	public AnimacionJugador(TextureAtlas atlas, Map<Estados, AnimacionConfig> configuracionesAnimacion) {
		super(atlas);
		animaciones = crearAnimaciones(configuracionesAnimacion);
	}

	private Map<Estados, Animation<TextureRegion>> crearAnimaciones(
			Map<Estados, AnimacionConfig> configuracionesAnimacion) {
		Map<Estados, Animation<TextureRegion>> animMap = new HashMap<>();
		for (Map.Entry<Estados, AnimacionConfig> entry : configuracionesAnimacion.entrySet()) {
			Estados estado = entry.getKey();
			AnimacionConfig config = entry.getValue();
			animMap.put(estado,
					createAnimation(config.getRegionName(), config.getNumFrames(), config.getFrameDuration()));
		}
		return animMap;
	}

	@Override
	public TextureRegion getFrame(Estados estadoActual, float deltaTime) {
		stateTime += deltaTime;
		switch (estadoActual) {
		case CAER:
			// Obtener el frame actual de la animación de caída
			TextureRegion currentFrame = animaciones.get(Estados.CAER).getKeyFrame(stateTime, false);
			// Verificar si la animación de caída ha terminado
			if (animaciones.get(Estados.CAER).isAnimationFinished(stateTime)) {
				return animaciones.get(Estados.CAYENDO).getKeyFrame(stateTime, true);
			}
			return currentFrame;

		case CAYENDO:
			return animaciones.get(Estados.CAYENDO).getKeyFrame(stateTime, true);

		default:
			return animaciones.getOrDefault(estadoActual, animaciones.get(Estados.IDLE)).getKeyFrame(stateTime, true);
		}

	}
}
