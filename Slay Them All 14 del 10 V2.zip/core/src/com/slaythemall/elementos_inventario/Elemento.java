package com.slaythemall.elementos_inventario;

import com.slaythemall.objetos.GameEntity;
import com.slaythemall.objetos.Jugador;

public abstract class Elemento {
	
	private String nombre;
	private int cantUsos;
	private TiposElemento tipoElemento;
	
	public Elemento(String nombre, int cantUsos, TiposElemento tipoElemento, GameEntity entidad) {
		this.nombre = nombre;
		this.cantUsos = cantUsos;
		this.tipoElemento = tipoElemento;
		ejecutarElemento(entidad);
	}
	
	private void ejecutarElemento(GameEntity entidad) {
		if(tipoElemento == TiposElemento.VIDA) {
			entidad.resetVida();
		}
	}
	
	public int getCantUsos() {
		return this.cantUsos;
	}
	
	public void restCantUsos() {
		this.cantUsos--;
	}
	

}
