package com.slaythemall.objetos;

import static com.slaythemall.utiles.Constantes.PPM;

import java.util.Map;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.Body;
import com.slaythemall.animaciones.AnimacionConfig;
import com.slaythemall.animaciones.AnimacionEnemigo;
import com.slaythemall.utiles.Recursos;

public class Enemigo extends GameEntity {
	protected AnimacionEnemigo animacionEnemigo;
	protected EstadoEnemigo estadoEnemigo; 

	public Enemigo(float ancho, float alto, Body body, String atlasPath, int vidaInicial,
			Map<Estados, AnimacionConfig> configAnimaciones) {
		super(ancho, alto, body);
		this.animacionEnemigo = new AnimacionEnemigo(new TextureAtlas(Gdx.files.internal(atlasPath)),
				configAnimaciones);
		this.estadoEnemigo = new EstadoEnemigo(); 
		this.vida = vidaInicial;
		this.body.setUserData(this);
	}

	@Override
	public void update() {
		if (this.vida <= 0) {
			eliminarCuerpoEnemigo();
			return;
		}

		x = body.getPosition().x * PPM;
		y = body.getPosition().y * PPM;

		estadoEnemigo.actualizarEstado(this);
	}

	@Override
	public void render(SpriteBatch batch) {
		if (this.vida > 0) {
			TextureRegion currentFrame = animacionEnemigo.getFrame(estadoEnemigo.getEstadoActual(),
					Gdx.graphics.getDeltaTime());
			if (currentFrame != null) {
				batch.draw(currentFrame, x - ancho / 2, y - alto / 2, ancho, alto);
			}
		}
	}

	public void recibirGolpe(float daño) {
		this.vida -= daño;
		System.out.println("AY ME PEGO");
		if (this.vida <= 0) {
			System.out.println("AY ME MUERO");
		}
		animacionEnemigo.resetStateTime(); // Reiniciar el tiempo de estado de la animación
		estadoEnemigo.setRecibiendoGolpe(true); // Establece que está recibiendo golpe
	}


	public void eliminarCuerpoEnemigo() {
		if (body != null) {
			// Eliminar el cuerpo del mundo físico
			body.getWorld().destroyBody(body);
			body = null; // Asegurarse de que el cuerpo se elimine completamente
		}
	}

	public int getVida() {
		return this.vida;
	}

	public void resetStateTime() {
		animacionEnemigo.resetStateTime(); // Reinicia el tiempo de la animación
	}

}
