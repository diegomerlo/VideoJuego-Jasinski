package com.slaythemall.objetos;

import java.lang.reflect.InvocationTargetException;

import com.badlogic.gdx.physics.box2d.Body;
import com.slaythemall.utiles.Recursos;

public enum TipoJugador {

	SAMURAI("Samurai", "com.slaythemall.objetos.Samurai");

    private String nombre;
    private String nombreClase;

    TipoJugador(String nombre, String nombreClase) {
        this.nombre = nombre;
        this.nombreClase = nombreClase;
    }

    public String getNombre() {
        return nombre;
    }

    public String getNombreClase() {
        return nombreClase;
    }
	
    public static Jugador obtenerPersonaje(int opc, float ancho, float alto, Body body) {
        Jugador jugador = null;
		
			try {
			Class clase = Class.forName(values()[opc].getNombreClase());
				jugador = (Jugador) clase.getDeclaredConstructor(float.class, float.class, Body.class).newInstance(ancho, alto, body);
			} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException e) {
				e.printStackTrace();
			}
		return jugador;
	}
}
