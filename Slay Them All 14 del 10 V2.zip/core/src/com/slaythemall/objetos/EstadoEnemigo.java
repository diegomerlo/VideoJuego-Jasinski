package com.slaythemall.objetos;

public class EstadoEnemigo {
    private Estados estadoActual;
    private Estados estadoAnterior;
    private boolean recibiendoGolpe; 
    public EstadoEnemigo() {
        estadoActual = Estados.IDLE; // Inicializa en el estado IDLE
        estadoAnterior = Estados.IDLE;
        recibiendoGolpe = false; 
    }

    public void actualizarEstado(Enemigo enemigo) {
       // Lógica para determinar el estado del enemigo
      //  boolean isAtacando = enemigo.isAtacando(); // Asegúrate de implementar este método en Enemigo
      //  boolean isCaminando = enemigo.isCaminando(); // Asegúrate de implementar este método en Enemigo

        // Cambios de estado basados en las condiciones
        if (recibiendoGolpe) {
            actualizarEstadoRecibiendoGolpe(enemigo);
        }  /*else if (isAtacando) {
            estadoActual = Estados.ATACAR;
        } else if (isCaminando) {
            estadoActual = Estados.CAMINAR;
        }*/ 
        else {
            estadoActual = Estados.IDLE; // Puedes expandir esto para incluir más estados
        }
        // Resetea el tiempo de estado si ha cambiado
        if (estadoActual != estadoAnterior) {
            enemigo.resetStateTime(); // Implementa este método en Enemigo
        }

        estadoAnterior = estadoActual;
    }

    public Estados getEstadoActual() {
        return estadoActual;
    }
    
    public void setRecibiendoGolpe(boolean valor) {
        recibiendoGolpe = valor; 
    }
    private void actualizarEstadoRecibiendoGolpe(Enemigo enemigo) {
        estadoActual = Estados.RECIBIR_GOLPE;
        if (enemigo.animacionEnemigo.isRecibirGolpeAnimationFinished()) {
            recibiendoGolpe = false;
            estadoActual = Estados.IDLE;
        }
    }
}
