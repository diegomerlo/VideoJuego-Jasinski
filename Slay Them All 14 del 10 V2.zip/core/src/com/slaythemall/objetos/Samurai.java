package com.slaythemall.objetos;

import java.util.Map;

import com.badlogic.gdx.physics.box2d.Body;
import com.slaythemall.animaciones.AnimacionConfig;
import com.slaythemall.utiles.Recursos;
import java.util.HashMap;
public class Samurai extends Jugador {

    public static final String ATLAS_PATH = Recursos.ANIMACIONES_SAMURAI;
    public static final float DAÑO = 50f;

    public Samurai(float ancho, float alto, Body body) {
        super(ancho, alto, body, ATLAS_PATH, DAÑO,getAnimacionConfig());
    }
    
    private static Map<Estados, AnimacionConfig> getAnimacionConfig() {
        Map<Estados, AnimacionConfig> config = new HashMap<>();
        config.put(Estados.IDLE, new AnimacionConfig("idle", 6, 0.1f));
        config.put(Estados.CAMINAR, new AnimacionConfig("caminar", 6, 0.1f));
        config.put(Estados.SALTAR, new AnimacionConfig("salto", 3, 0.1f));
        config.put(Estados.CAER, new AnimacionConfig("caida", 3, 0.1f));
        config.put(Estados.DASH, new AnimacionConfig("dash", 5, 0.08f));
        config.put(Estados.ATACAR, new AnimacionConfig("atacarA", 6, 0.1f));
        config.put(Estados.CAYENDO, new AnimacionConfig("caida_repeticion",2, 0.1f));
        return config;
    }
    
}
