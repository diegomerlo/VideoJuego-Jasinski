package com.slaythemall.objetos;

public class EstadoJugador {
	private Estados estadoActual;
	private Estados estadoAnterior;

	public EstadoJugador() {
		estadoActual = Estados.IDLE;
		estadoAnterior = Estados.IDLE;
	}

	public void actualizarEstado(Jugador jugador) {
		boolean isJumping = jugador.isJumping();
		boolean isFalling = jugador.isFalling();
		boolean isWalking = jugador.isWalking();
		boolean isDashing = jugador.isDashing();
		boolean isAttacking = jugador.isAttacking(); 

		if (isAttacking) {
			estadoActual = Estados.ATACAR;
		} else if (isJumping) {
			estadoActual = Estados.SALTAR;
		} else if (isDashing) {
			estadoActual = Estados.DASH;
		} else if (isFalling) {
			estadoActual = Estados.CAER;
		} else if (isWalking) {
			estadoActual = Estados.CAMINAR;
		} else {
			estadoActual = Estados.IDLE;
		}

		if (estadoActual != estadoAnterior) {
			jugador.resetStateTime();
		}

		estadoAnterior = estadoActual;
	}

	public Estados getEstadoActual() {
		return estadoActual;
	}
}
