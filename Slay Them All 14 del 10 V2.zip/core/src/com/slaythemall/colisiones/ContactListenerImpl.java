package com.slaythemall.colisiones;

import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.Manifold;
import com.slaythemall.objetos.Jugador;
import com.slaythemall.objetos.Enemigo;

public class ContactListenerImpl implements ContactListener {

	@Override
	public void beginContact(Contact contacto) {
		Fixture fixtureA = contacto.getFixtureA();
		Fixture fixtureB = contacto.getFixtureB();

		if (fixtureA.getUserData() != null && fixtureA.getUserData().equals("sensorEspada")) {

			if (fixtureB.getBody().getUserData() instanceof Enemigo) {
				Enemigo enemigo = (Enemigo) fixtureB.getBody().getUserData();
				Jugador jugador = (Jugador) fixtureA.getBody().getUserData();
				jugador.setEnemyContact(enemigo); // Guardar el enemigo con el que se está en contacto
			}

		}

		// Verificación para sensorEspada en fixtureB
		if (fixtureB.getUserData() != null && fixtureB.getUserData().equals("sensorEspada")) {

			if (fixtureA.getBody().getUserData() instanceof Enemigo) {
				Enemigo enemigo = (Enemigo) fixtureA.getBody().getUserData();
				Jugador jugador = (Jugador) fixtureB.getBody().getUserData();
				jugador.setEnemyContact(enemigo);
			}

		}

		// Verificación para sensorPies en fixtureA
		if (fixtureA.getUserData() != null && fixtureA.getUserData().equals("sensorPies")) {
			((Jugador) fixtureA.getBody().getUserData()).setTocandoSuelo(true);
		}

		// Verificación para sensorPies en fixtureB
		if (fixtureB.getUserData() != null && fixtureB.getUserData().equals("sensorPies")) {
			((Jugador) fixtureB.getBody().getUserData()).setTocandoSuelo(true);
		}
	}

	@Override
	public void endContact(Contact contacto) {
		Fixture fixtureA = contacto.getFixtureA();
		Fixture fixtureB = contacto.getFixtureB();

		// Verificación para sensorEspada en fixtureA
		if (fixtureA.getUserData() != null && fixtureA.getUserData().equals("sensorEspada")) {
			if (fixtureB.getBody().getUserData() instanceof Enemigo) {
				Jugador jugador = (Jugador) fixtureA.getBody().getUserData();
				jugador.setEnemyContact(null); // Clear the contact
			}
		}

		// Verificación para sensorEspada en fixtureB
		if (fixtureB.getUserData() != null && fixtureB.getUserData().equals("sensorEspada")) {
			if (fixtureA.getBody().getUserData() instanceof Enemigo) {
				Jugador jugador = (Jugador) fixtureB.getBody().getUserData();
				jugador.setEnemyContact(null); // Clear the contact
			}
		}

		// Verificación para sensorPies en fixtureA
		if (fixtureA.getUserData() != null && fixtureA.getUserData().equals("sensorPies")) {
			((Jugador) fixtureA.getBody().getUserData()).setTocandoSuelo(false);
		}

		// Verificación para sensorPies en fixtureB
		if (fixtureB.getUserData() != null && fixtureB.getUserData().equals("sensorPies")) {
			((Jugador) fixtureB.getBody().getUserData()).setTocandoSuelo(false);
		}
	}

	@Override
	public void preSolve(Contact contact, Manifold oldManifold) {

	}

	@Override
	public void postSolve(Contact contact, ContactImpulse impulse) {

	}
}
