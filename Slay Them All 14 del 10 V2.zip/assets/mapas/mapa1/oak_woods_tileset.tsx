<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="oak_woods_tileset" tilewidth="16" tileheight="16" tilecount="682" columns="31">
 <image source="oak_woods_tileset.png" width="504" height="360"/>
</tileset>
