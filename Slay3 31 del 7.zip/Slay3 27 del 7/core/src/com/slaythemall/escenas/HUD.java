package com.slaythemall.escenas;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.slaythemall.utiles.Config;

public class HUD {
	public Stage stage;
	private Viewport viewport;
	
	private int tiempo;
	private float contadorTiempo;
	private int puntaje;
	
	
	Label contadorLabel;
	Label puntajeLabel;
	Label tiempoLabel;
	Label nivelLabel;
	Label personajeLabel;
	
	public HUD(SpriteBatch b) {
		this.tiempo = 0;
		this.contadorTiempo = 0;
		this.puntaje = 0;
		this.viewport = new FitViewport(Config.ANCHO, Config.ALTO, new OrthographicCamera());
		this.stage = new Stage(viewport, b);
		
		Table table = new Table();
		table.top();
		table.setFillParent(true);
		
		this.contadorLabel = new Label(String.format("%03d", this.tiempo),new Label.LabelStyle(new BitmapFont(), Color.WHITE));
		this.puntajeLabel = new Label(String.format("%06d", this.puntaje),new Label.LabelStyle(new BitmapFont(), Color.WHITE));
		this.tiempoLabel = new Label("Tiempo:", new Label.LabelStyle(new BitmapFont(), Color.WHITE));
		this.nivelLabel = new Label("NIVEL 1", new Label.LabelStyle(new BitmapFont(), Color.WHITE));
		this.personajeLabel = new Label("JORGE", new Label.LabelStyle(new BitmapFont(), Color.WHITE));

		table.add(personajeLabel).expandX().padTop(10).left();
		table.add(nivelLabel).expandX().padTop(10).center();
		table.add(tiempoLabel).padTop(10).right();
		table.add(contadorLabel).padTop(10).right();
		table.row();
		table.add(puntajeLabel).colspan(4).expandX().left();
		
		stage.addActor(table);
		
	}
	
    public void setContadorTiempo(float contadorTiempo) {
        this.contadorTiempo = contadorTiempo;
    }

    public void setTiempo(int tiempo) {
        this.tiempo = tiempo;
    }

    public float getContadorTiempo() {
        return contadorTiempo;
    }

    public int getTiempo() {
        return tiempo;
    }

    public Label getContadorLabel() {
        return contadorLabel;
    }
}
