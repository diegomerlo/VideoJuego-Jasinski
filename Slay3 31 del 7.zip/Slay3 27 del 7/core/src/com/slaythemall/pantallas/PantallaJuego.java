package com.slaythemall.pantallas;

import static com.slaythemall.utiles.Constantes.PPM;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.slaythemall.colisiones.ContactListenerImpl;
import com.slaythemall.escenas.HUD;
import com.slaythemall.mapas.TiledMaps;
import com.slaythemall.objetos.Enemigo;
import com.slaythemall.objetos.Jugador;
import com.slaythemall.utiles.Config;

public class PantallaJuego extends ScreenAdapter {

    private OrthographicCamera camara;
    private Viewport viewport;
    private SpriteBatch batch;
    private World mundo;
    private Box2DDebugRenderer box2DDebugRenderer;
    private OrthogonalTiledMapRenderer orthogonalTiledMapRenderer;
    private TiledMaps tiledMaps;
    private Jugador jugador;
    private Enemigo[] enemigos;
    private HUD hud;

    public PantallaJuego() {
        // Configura la cámara y el viewport
        this.camara = new OrthographicCamera();
        this.viewport = new FitViewport(Config.ANCHO, Config.ALTO, camara);
        this.camara.setToOrtho(false, Config.ANCHO, Config.ALTO);
        this.batch = new SpriteBatch();
        this.mundo = new World(new Vector2(0, -25f), false);
        this.box2DDebugRenderer = new Box2DDebugRenderer();
        this.tiledMaps = new TiledMaps(this);
        this.orthogonalTiledMapRenderer = tiledMaps.iniciarMapa();
        this.mundo.setContactListener(new ContactListenerImpl());
        this.hud = new HUD(this.batch);
    }

    private void update() {
        mundo.step(1 / 60f, 6, 2);
        camaraActualizar();
        viewport.apply(); // Aplica los cambios del viewport
        batch.setProjectionMatrix(camara.combined);
        orthogonalTiledMapRenderer.setView(camara);
        jugador.update();

        hudUpdate(Gdx.graphics.getDeltaTime());

        if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
            Gdx.app.exit();
        }
    }

    private void camaraActualizar() {
        Vector3 position = camara.position;
        position.x = Math.round(jugador.getBody().getPosition().x * PPM * 10) / 10f;
        position.y = Math.round(jugador.getBody().getPosition().y * PPM * 10) / 10f;
        camara.position.set(position);
        camara.update();
    }

    private void hudUpdate(float delta) {
        hud.setContadorTiempo(hud.getContadorTiempo() + delta);
        if (hud.getContadorTiempo() >= 1) {
            hud.setTiempo(hud.getTiempo() + 1);
            hud.getContadorLabel().setText(String.format("%03d", hud.getTiempo()));
            hud.setContadorTiempo(0);
        }
    }

    @Override
    public void render(float delta) {
        this.update();
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        orthogonalTiledMapRenderer.render();
        batch.setProjectionMatrix(camara.combined);
        batch.begin();

        jugador.render(batch);

        for (Enemigo enemigo : enemigos) {
            enemigo.update();
            enemigo.render(batch);
        }
        batch.end();

        // Renderizar HUD
        batch.setProjectionMatrix(hud.stage.getCamera().combined);
        hud.stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
    }

    public World getMundo() {
        return mundo;
    }

    public void setJugador(Jugador jugador) {
        this.jugador = jugador;
    }

    public void setEnemigos(Enemigo[] enemigos) {
        this.enemigos = enemigos;
    }

    public Jugador getJugador() {
        return this.jugador;
    }

    @Override
    public void dispose() {
        // Limpiar recursos
    }
}
