package com.slaythemall.pantallas;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Slider;
import com.badlogic.gdx.scenes.scene2d.ui.Slider.SliderStyle;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.slaythemall.elementos.Imagen;
import com.slaythemall.elementos.Texto;
import com.slaythemall.musicas.efectoSonido;
import com.slaythemall.musicas.musicaAmbiente;
import com.slaythemall.utiles.Config;
import com.slaythemall.utiles.Recursos;
import com.slaythemall.utiles.Render;

public class PantallaOpciones implements Screen {
    
    private Imagen fondo;
    private SpriteBatch b;
    private Stage stage;
    private Slider backgroundMusicSlider;
    private Slider efectosSonidoSlider;
    private Texto textos[] = new Texto[2];
    private ImageButton backButton;
    
    @Override
    public void show() {
        // Cargar el fondo del menú
        fondo = new Imagen(Recursos.FONDO_MENU);
        b = Render.batch;

        // Configurar el escenario
        stage = new Stage(new ScreenViewport());
        Gdx.input.setInputProcessor(stage);

        // Cargar texturas para el slider
        Texture backgroundTexture = new Texture(Gdx.files.internal(Recursos.SLIDER_BACKGROUND));
        Texture knobTexture = new Texture(Gdx.files.internal(Recursos.SLIDER_KNOB));

        // Crear drawables a partir de las texturas
        Drawable backgroundDrawable = new TextureRegionDrawable(backgroundTexture);
        Drawable knobDrawable = new TextureRegionDrawable(knobTexture);

        //--------Configuracion Slider BACKGROUND MUSICA ------

        // Crear el estilo del slider manualmente
        SliderStyle sliderBackgroundMusic = new SliderStyle();
        sliderBackgroundMusic.background = backgroundDrawable;
        sliderBackgroundMusic.knob = knobDrawable;

        // Crear el slider con el estilo personalizado
        backgroundMusicSlider = new Slider(0, 10, 1, false, sliderBackgroundMusic);
        backgroundMusicSlider.setValue(1); // Establecer el valor inicial del volumen
        backgroundMusicSlider.addListener(event -> {
            float volume = backgroundMusicSlider.getValue() / 10f;
            musicaAmbiente.AMBIENTE_PRINCIPAL.setVolume(volume);
            return false;
        });

        // Configurar la posición y tamaño del slider
        backgroundMusicSlider.setSize(200, 40);
        backgroundMusicSlider.setPosition((Config.ANCHO/2)-(200/2), Config.ALTO/2-50);
        
      //--------Texto Background Music ------
        textos[0] = new Texto(Recursos.FUENTE_MENU, 30, Color.WHITE, false);
        textos[0].setTexto("Background Music");
        textos[0].setPosicion((Config.ANCHO / 2) - (textos[0].getAncho() / 2), Config.ALTO / 2 + 50);
        
        
        //--------Configuracion Slider EFECTOS SONIDO ------

        
        SliderStyle sliderEfectosSonido = new SliderStyle();
        sliderEfectosSonido.background = backgroundDrawable;
        sliderEfectosSonido.knob = knobDrawable;
        
        efectosSonidoSlider = new Slider(0, 10, 1, false, sliderEfectosSonido);
        efectosSonidoSlider.setValue(10); // Establecer el valor inicial del volumen
        efectosSonidoSlider.addListener(event -> {
            float volume = efectosSonidoSlider.getValue() / 10f;
            efectoSonido.setVolume(volume);
            return false;
        });

        // Configurar la posición y tamaño del slider
        efectosSonidoSlider.setSize(200, 40);
        efectosSonidoSlider.setPosition((Config.ANCHO/2)-(200/2), Config.ALTO/2-200);

      //--------Texto Efectos Sonido ------
        textos[1] = new Texto(Recursos.FUENTE_MENU, 30, Color.WHITE, false);
        textos[1].setTexto("Efectos Sonido");
        textos[1].setPosicion((Config.ANCHO / 2) - (textos[1].getAncho() / 2), Config.ALTO / 2 - 100);

      //--------Botón de regreso (flecha) ------
        // Cargar la textura de la flecha
        Texture backTexture = new Texture(Gdx.files.internal(Recursos.FLECHA_ATRAS));
        Drawable backDrawable = new TextureRegionDrawable(backTexture);

        // Crear el botón de imagen con la textura de la flecha
        backButton = new ImageButton(backDrawable);

        // Posicionar el botón en la esquina superior izquierda
        backButton.setSize(50, 50);
        backButton.setPosition(20, Config.ALTO - backButton.getHeight() - 20);

        // Añadir listener para regresar al menú
        backButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                // Cambiar de pantalla al menú principal
                Render.app.setScreen(new PantallaMenu());
            }
        });
        
        // Añadir el slider al escenario
        stage.addActor(backgroundMusicSlider);
        stage.addActor(efectosSonidoSlider);
        stage.addActor(backButton);
    }

    @Override
    public void render(float delta) {
        // Limpiar la pantalla
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        // Dibujar el fondo y el escenario
        b.begin();
        	fondo.dibujar();
        	textos[0].dibujar();
        	textos[1].dibujar();
        b.end();

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void pause() {}

    @Override
    public void resume() {}

    @Override
    public void hide() {}

    @Override
    public void dispose() {
        // Liberar recursos
        stage.dispose();
    }
}
