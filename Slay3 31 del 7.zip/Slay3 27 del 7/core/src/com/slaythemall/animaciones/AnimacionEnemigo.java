package com.slaythemall.animaciones;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.slaythemall.objetos.Estados;

public class AnimacionEnemigo extends Animacion {
    private Animation<TextureRegion> idleAnimation;
    private Animation<TextureRegion> recibirGolpeAnimation;

    public AnimacionEnemigo(TextureAtlas atlas) {
        super(atlas);
        idleAnimation = createAnimation("idle", 4, 0.2f);
        recibirGolpeAnimation = createAnimation("recibir_golpe", 5, 0.1f);
    }

    @Override
    public TextureRegion getFrame(Estados estadoActual, float deltaTime) {
        stateTime += deltaTime;
        switch (estadoActual) {
            case RECIBIR_GOLPE:
                return recibirGolpeAnimation.getKeyFrame(stateTime, true);
            case IDLE:
            default:
                return idleAnimation.getKeyFrame(stateTime, true);
        }
    }
}
