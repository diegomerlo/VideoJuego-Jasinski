package com.slaythemall.colisiones;

//import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.Manifold;
import com.slaythemall.objetos.Jugador;

public class ContactListenerImpl implements ContactListener {

    @Override
    public void beginContact(Contact contact) {
        Fixture fixtureA = contact.getFixtureA();
        Fixture fixtureB = contact.getFixtureB();

        if (fixtureA.getUserData() != null && fixtureA.getUserData().equals("sensorPies")) {
           // Gdx.app.log("Contact", "Jugador tocando el suelo - fixtureA");
            ((Jugador) fixtureA.getBody().getUserData()).setTocandoSuelo(true);
        }

        if (fixtureB.getUserData() != null && fixtureB.getUserData().equals("sensorPies")) {
            //Gdx.app.log("Contact", "Jugador tocando el suelo - fixtureB");
            ((Jugador) fixtureB.getBody().getUserData()).setTocandoSuelo(true);
        }
    }

    @Override
    public void endContact(Contact contact) {
        Fixture fixtureA = contact.getFixtureA();
        Fixture fixtureB = contact.getFixtureB();

        if (fixtureA.getUserData() != null && fixtureA.getUserData().equals("sensorPies")) {
           // Gdx.app.log("Contact", "Jugador dejó de tocar el suelo - fixtureA");
            ((Jugador) fixtureA.getBody().getUserData()).setTocandoSuelo(false);
        }

        if (fixtureB.getUserData() != null && fixtureB.getUserData().equals("sensorPies")) {
          //  Gdx.app.log("Contact", "Jugador dejó de tocar el suelo - fixtureB");
            ((Jugador) fixtureB.getBody().getUserData()).setTocandoSuelo(false);
        }
    }

    @Override
    public void preSolve(Contact contact, Manifold oldManifold) {
    }

    @Override
    public void postSolve(Contact contact, ContactImpulse impulse) {
    }
}
