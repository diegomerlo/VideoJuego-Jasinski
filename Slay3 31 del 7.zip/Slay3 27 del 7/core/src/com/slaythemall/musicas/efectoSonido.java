package com.slaythemall.musicas;

import com.slaythemall.utiles.Recursos;

public abstract class efectoSonido {

	public static final Musica EFECTO_SALTO = new Musica(Recursos.EFECTO_SONIDO_SALTAR);
	public static final Musica EFECTO_CAMINAR = new Musica(Recursos.EFECTO_SONIDO_CAMINAR);
	public static final Musica EFECTO_DASH = new Musica(Recursos.EFECTO_SONIDO_DASH);
    

	//para liberar recursos
    public static void dispose() {
        EFECTO_SALTO.dispose();
        EFECTO_CAMINAR.dispose();
        EFECTO_DASH.dispose();
    }
    
    public static void setVolume(float volume) {
    	EFECTO_SALTO.setVolume(volume);
    	EFECTO_CAMINAR.setVolume(volume);
    	EFECTO_DASH.setVolume(volume);
    }
}
