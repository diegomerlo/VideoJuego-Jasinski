<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="lamp" tilewidth="23" tileheight="57" tilecount="1" columns="1">
 <image source="lamp.png" width="23" height="57"/>
</tileset>
