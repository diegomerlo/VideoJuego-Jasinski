<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="background_layer_3" tilewidth="320" tileheight="180" tilecount="1" columns="1">
 <image source="background_layer_3.png" width="320" height="180"/>
</tileset>
