package com.slaythemall.objetos;

public class EstadoJugador {
	private Estados estadoActual;
	private Estados estadoAnterior;
	private boolean recibiendoGolpe; // Nuevo campo para representar si está recibiendo daño
	private float tiempoRecibiendoGolpe;
	private final float DURACION_RECIBIR_GOLPE = 0.5f; // Duración en segundos
	
	public EstadoJugador() {
		estadoActual = Estados.IDLE;
		estadoAnterior = Estados.IDLE;
		recibiendoGolpe = false; // Inicialmente no está recibiendo daño
		tiempoRecibiendoGolpe = 0;
	}

	public void actualizarEstado(Jugador jugador,float delta) {
		boolean isJumping = jugador.isJumping();
		boolean isFalling = jugador.isFalling();
		boolean isWalking = jugador.isWalking();
		boolean isDashing = jugador.isDashing();
		boolean isAttacking = jugador.isAttacking();

		if (recibiendoGolpe) { 
			estadoActual = Estados.RECIBIR_GOLPE;
			tiempoRecibiendoGolpe += delta;
        if (tiempoRecibiendoGolpe >= DURACION_RECIBIR_GOLPE) {
            recibiendoGolpe = false; // Resetear estado después del tiempo
            tiempoRecibiendoGolpe = 0;
        }
		} else if (isAttacking) {
			estadoActual = Estados.ATACAR;
			
		} else if (isJumping) {
			estadoActual = Estados.SALTAR;
		} else if (isDashing) {
			estadoActual = Estados.DASH;
		} else if (isFalling) {
			estadoActual = Estados.CAER;
		} else if (isWalking) {
			estadoActual = Estados.CAMINAR;
		} else {
			estadoActual = Estados.IDLE;
		}

		if (estadoActual != estadoAnterior) {
			jugador.resetStateTime();
			tiempoRecibiendoGolpe = 0; // Resetear temporizador si cambia de estado
		}

		estadoAnterior = estadoActual;
	}

	public Estados getEstadoActual() {
		return estadoActual;
	}
	
	  public void setRecibiendoGolpe(boolean valor) {
	        recibiendoGolpe = valor;
	    }
	  
}
