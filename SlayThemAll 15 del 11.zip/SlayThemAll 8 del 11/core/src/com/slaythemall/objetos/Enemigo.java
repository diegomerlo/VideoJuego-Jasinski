package com.slaythemall.objetos;

import static com.slaythemall.utiles.Constantes.PPM;

import java.util.Map;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.slaythemall.animaciones.AnimacionConfig;
import com.slaythemall.animaciones.AnimacionEnemigo;
import com.slaythemall.pantallas.PantallaJuego;
import com.slaythemall.utiles.Recursos;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;

public class Enemigo extends GameEntity {
	protected AnimacionEnemigo animacionEnemigo;
	protected EstadoEnemigo estadoEnemigo;
	protected boolean isFacingRight;
	protected float velocidad;
	private Fixture sensorAtaque; // El sensor temporal
	private float empuje = 10;
	private boolean atacando;
	private boolean caminando;
	private float rangoAtaque = 1.5f; // Distancia mínima para atacar
	private float velocidadMovimiento = 0.5f;
	protected Jugador jugador;
	protected float daño;

	public Enemigo(float ancho, float alto, Body body, String atlasPath, int vidaInicial,
			Map<Estados, AnimacionConfig> configAnimaciones, Jugador jugador, float daño) {
		super(ancho, alto, body);
		this.animacionEnemigo = new AnimacionEnemigo(new TextureAtlas(Gdx.files.internal(atlasPath)),
				configAnimaciones);
		this.estadoEnemigo = new EstadoEnemigo();
		this.vida = vidaInicial;
		this.body.setUserData(this);
		this.isFacingRight = true; // Por defecto mira a la derecha
		this.velocidad = 2.0f; // Velocidad base del enemigo
		this.atacando = false;
		this.caminando = false;
		this.jugador = jugador;
		this.daño = daño;
	}

	@Override
	public void update() {
		if (this.vida <= 0) {
			eliminarCuerpoEnemigo();
			return;
		}

		x = body.getPosition().x * PPM;
		y = body.getPosition().y * PPM;

		estadoEnemigo.actualizarEstado(this, Gdx.graphics.getDeltaTime());
		verificarAtaque();
		verificarMovimiento();

		if (!atacando) {
			perseguirJugador();
		} else {
			// Si está atacando, detener movimiento
			body.setLinearVelocity(0, body.getLinearVelocity().y); // Detiene el movimiento solo en el eje X
		}
	}

	@Override
	public void render(SpriteBatch batch) {
		TextureRegion currentFrame = animacionEnemigo.getFrame(estadoEnemigo.getEstadoActual(),
				Gdx.graphics.getDeltaTime());

		if (currentFrame != null) {
			float drawX = x - ancho / 2;
			float drawY = y - alto / 2;

			if (isFacingRight) {
				// Animacion en carpeta mira hacia la izquierda, por eso se invierte en el
				// facingRight
				batch.draw(currentFrame, drawX + ancho, drawY, -ancho, alto);
			} else {
				batch.draw(currentFrame, drawX, drawY, ancho, alto);
			}
		}
	}

	public void recibirGolpe(float daño) {
		this.vida -= daño;
		System.out.println("AY ME PEGO");
		if (this.vida <= 0) {
			System.out.println("AY ME MUERO");
		}
		animacionEnemigo.resetStateTime(); // Reiniciar el tiempo de estado de la animación
		estadoEnemigo.setRecibiendoGolpe(true); // Establece que está recibiendo golpe
	}

	public void eliminarCuerpoEnemigo() {
		if (body != null) {
			// Eliminar el cuerpo del mundo físico
			body.getWorld().destroyBody(body);
			body = null; // Asegurarse de que el cuerpo se elimine completamente
		}
	}

	public int getVida() {
		return this.vida;
	}

	public void resetStateTime() {
		animacionEnemigo.resetStateTime(); // Reinicia el tiempo de la animación
	}

	public void setFacingRight(boolean facingRight) {
		this.isFacingRight = facingRight;
	}

	public boolean isFacingRight() {
		return isFacingRight;
	}

	public float getDaño() {
		return daño;
	}

	public void aplicarDaño(Jugador jugador) {
		jugador.recibirDaño(daño); // Aplicar daño al jugador
	}

	public void activarSensorAtaque() {
		if (sensorAtaque == null) {
			orientarSensorAtaque();
		}
	}

	private void orientarSensorAtaque() {
		if (sensorAtaque != null) {
			body.destroyFixture(sensorAtaque);
		}

		FixtureDef sensorDef = new FixtureDef();
		PolygonShape sensorShape = new PolygonShape();

		// Crear el sensor a la derecha o izquierda según `isFacingRight`
		float offsetX = isFacingRight ? 1.0f : -1.0f;
		sensorShape.setAsBox(0.5f, 0.5f, new Vector2(offsetX, 0), 0);

		sensorDef.shape = sensorShape;
		sensorDef.isSensor = true;
		sensorAtaque = body.createFixture(sensorDef);
		sensorAtaque.setUserData("sensorAtaqueEnemigo");

		sensorShape.dispose();
	}

	public void desactivarSensorAtaque() {
		// Elimina el sensor si existe
		if (sensorAtaque != null) {
			body.destroyFixture(sensorAtaque);
			sensorAtaque = null;
		}
	}

	// Verifica si el jugador está dentro del rango de ataque
	private void verificarAtaque() {
	    if (!atacando) { // Solo verifica si no está ya atacando
	        float distanciaJugador = calcularDistanciaAlJugador();
	        
	        if (distanciaJugador < rangoAtaque) {
	            atacando = true;
	            activarSensorAtaque();
	        }
	    } else {
	        // Desactivar el sensor si el enemigo ya no está dentro del rango o en contacto
	        float distanciaJugador = calcularDistanciaAlJugador();
	        if (distanciaJugador >= rangoAtaque) {
	            atacando = false;
	            desactivarSensorAtaque();
	        }
	    }
	}

	// Verifica si el enemigo debe caminar hacia el jugador o patrullar
	private void verificarMovimiento() {
		float distancia = calcularDistanciaAlJugador();

		// Solo puede moverse si no está atacando y está más allá de la distancia de
		// ataque
		if (!atacando && distancia > rangoAtaque) {
			caminando = true;
			perseguirJugador();
		} else {
			caminando = false;
			body.setLinearVelocity(0, body.getLinearVelocity().y); // Detiene el movimiento si está dentro del rango
		}
	}

	// Calcula la distancia entre el enemigo y el jugador
	private float calcularDistanciaAlJugador() {
		float playerXPosition = jugador.getBody().getPosition().x;
		float playerYPosition = jugador.getBody().getPosition().y;

		return Vector2.dst(this.body.getPosition().x, this.body.getPosition().y, playerXPosition, playerYPosition);

	}

	// Mueve al enemigo hacia el jugador con comportamiento de persecución
	private void perseguirJugador() {
		float dx = jugador.getBody().getPosition().x - this.body.getPosition().x;

		// Actualiza isFacingRight solo si cambia de dirección
		if ((dx > 0 && !isFacingRight) || (dx < 0 && isFacingRight)) {
			setFacingRight(dx > 0);
		}

		if (Math.abs(dx) > rangoAtaque) {
			float moveX = dx > 0 ? velocidadMovimiento : -velocidadMovimiento;
			body.setLinearVelocity(moveX, body.getLinearVelocity().y);
		} else {
			body.setLinearVelocity(0, body.getLinearVelocity().y);
		}
	
	}

	public boolean isAtacando() {
		return atacando;

	}

	public boolean isCaminando() {
		return caminando;

	}

	public float getEmpuje() {
		return empuje;
	}
	public void setAtacando(boolean atacando) {
	    this.atacando = atacando;
	}
}
