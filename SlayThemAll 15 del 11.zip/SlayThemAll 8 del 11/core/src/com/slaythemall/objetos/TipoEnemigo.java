package com.slaythemall.objetos;

import java.lang.reflect.InvocationTargetException;
import com.badlogic.gdx.physics.box2d.Body;

public enum TipoEnemigo {
    TRAINING_DUMMY("TrainingDummy", "com.slaythemall.objetos.TrainingDummy"),
    ARCHER("Archer", "com.slaythemall.objetos.Archer"),
    GUERRERO("Guerrero", "com.slaythemall.objetos.Guerrero");

    private String nombre;
    private String nombreClase;

    TipoEnemigo(String nombre, String nombreClase) {
        this.nombre = nombre;
        this.nombreClase = nombreClase;
    }

    public String getNombre() {
        return nombre;
    }

    public String getNombreClase() {
        return nombreClase;
    }

    public static Enemigo obtenerEnemigo(String tipoEnemigo, float ancho, float alto, Body body, Jugador jugador) {
        Enemigo enemigo = null;

        try {
            for (TipoEnemigo tipo : values()) {
                if (tipo.getNombre().equalsIgnoreCase(tipoEnemigo)) {
                    Class clase = Class.forName(tipo.getNombreClase());
                    enemigo = (Enemigo) clase.getDeclaredConstructor(float.class, float.class, Body.class,Jugador.class)
                            .newInstance(ancho, alto, body,jugador);
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | IllegalArgumentException
                | InvocationTargetException | NoSuchMethodException | SecurityException e) {
            e.printStackTrace();
        }
        System.out.println("Enemigo " + tipoEnemigo + " creado");
        return enemigo;
    }
}
