package com.slaythemall.colisiones;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Contact;
import com.badlogic.gdx.physics.box2d.ContactImpulse;
import com.badlogic.gdx.physics.box2d.ContactListener;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.Manifold;
import com.slaythemall.objetos.Jugador;
import com.slaythemall.objetos.Enemigo;

public class ContactListenerImpl implements ContactListener {

	@Override
	public void beginContact(Contact contacto) {
		Fixture fixtureA = contacto.getFixtureA();
		Fixture fixtureB = contacto.getFixtureB();
		
		 // Verificar si uno de los contactos es un sensor de ataque
        boolean isSensorA = fixtureA.isSensor();
        boolean isSensorB = fixtureB.isSensor();

        if (isSensorA && isSensorB) {
            // Ambos son sensores, ignoramos esta colisión entre sensores de ataque
            return;
        }
		if (fixtureA.getUserData() != null && fixtureA.getUserData().equals("sensorEspada")) {

			if (fixtureB.getBody().getUserData() instanceof Enemigo) {
				Enemigo enemigo = (Enemigo) fixtureB.getBody().getUserData();
				Jugador jugador = (Jugador) fixtureA.getBody().getUserData();
				jugador.setEnemyContact(enemigo); // Guardar el enemigo con el que se está en contacto
			}

		}

		// Verificación para sensorEspada en fixtureB
		if (fixtureB.getUserData() != null && fixtureB.getUserData().equals("sensorEspada")) {

			if (fixtureA.getBody().getUserData() instanceof Enemigo) {
				Enemigo enemigo = (Enemigo) fixtureA.getBody().getUserData();
				Jugador jugador = (Jugador) fixtureB.getBody().getUserData();
				jugador.setEnemyContact(enemigo);
			}

		}

		// Verificación para sensorPies en fixtureA
		if (fixtureA.getUserData() != null && fixtureA.getUserData().equals("sensorPies")) {
			((Jugador) fixtureA.getBody().getUserData()).setTocandoSuelo(true);
		}

		// Verificación para sensorPies en fixtureB
		if (fixtureB.getUserData() != null && fixtureB.getUserData().equals("sensorPies")) {
			((Jugador) fixtureB.getBody().getUserData()).setTocandoSuelo(true);
		}
		
		if (fixtureA.getUserData() != null && fixtureA.getUserData().equals("sensorAtaqueEnemigo")) {
	        if (fixtureB.getBody().getUserData() instanceof Jugador) {
	            Enemigo enemigo = (Enemigo) fixtureA.getBody().getUserData();
	            Jugador jugador = (Jugador) fixtureB.getBody().getUserData();
	            jugador.recibirDaño(enemigo.getDaño()); // Aplicar daño al jugador
	           jugador.aplicarEmpuje(enemigo.getEmpuje(),enemigo); // Aplica un empuje al jugador
	        }
	    }

	    if (fixtureB.getUserData() != null && fixtureB.getUserData().equals("sensorAtaqueEnemigo")) {
	        if (fixtureA.getBody().getUserData() instanceof Jugador) {
	            Enemigo enemigo = (Enemigo) fixtureB.getBody().getUserData();
	            Jugador jugador = (Jugador) fixtureA.getBody().getUserData();
	            jugador.recibirDaño(enemigo.getDaño());
	            jugador.aplicarEmpuje(enemigo.getEmpuje(),enemigo);
	        }
	    }
	}

	@Override
	public void endContact(Contact contacto) {
		Fixture fixtureA = contacto.getFixtureA();
		Fixture fixtureB = contacto.getFixtureB();

		// Verificación para sensorEspada en fixtureA
		if (fixtureA.getUserData() != null && fixtureA.getUserData().equals("sensorEspada")) {
			if (fixtureB.getBody().getUserData() instanceof Enemigo) {
				Jugador jugador = (Jugador) fixtureA.getBody().getUserData();
				jugador.setEnemyContact(null); // Clear the contact
			}
		}

		// Verificación para sensorEspada en fixtureB
		if (fixtureB.getUserData() != null && fixtureB.getUserData().equals("sensorEspada")) {
			if (fixtureA.getBody().getUserData() instanceof Enemigo) {
				Jugador jugador = (Jugador) fixtureB.getBody().getUserData();
				jugador.setEnemyContact(null); // Clear the contact
			}
		}

		// Verificación para sensorPies en fixtureA
		if (fixtureA.getUserData() != null && fixtureA.getUserData().equals("sensorPies")) {
			((Jugador) fixtureA.getBody().getUserData()).setTocandoSuelo(false);
		}

		// Verificación para sensorPies en fixtureB
		if (fixtureB.getUserData() != null && fixtureB.getUserData().equals("sensorPies")) {
			((Jugador) fixtureB.getBody().getUserData()).setTocandoSuelo(false);
		}
	}

	@Override
	public void preSolve(Contact contacto, Manifold oldManifold) {
	    Fixture fixtureA = contacto.getFixtureA();
	    Fixture fixtureB = contacto.getFixtureB();
	    
	    Object userDataA = fixtureA.getBody().getUserData();
	    Object userDataB = fixtureB.getBody().getUserData();

	    // Desactivar colisión entre enemigos
	    if (userDataA instanceof Enemigo && userDataB instanceof Enemigo) {
	        contacto.setEnabled(false);
	    }

	    // Desactivar colisión entre jugador y enemigo y aplicar daño y empuje
	    if ((userDataA instanceof Jugador && userDataB instanceof Enemigo) ||
	        (userDataA instanceof Enemigo && userDataB instanceof Jugador)) {
	        
	        contacto.setEnabled(false);
	        
	        Enemigo enemigo = userDataA instanceof Enemigo ? (Enemigo) userDataA : (Enemigo) userDataB;
	        Jugador jugador = userDataA instanceof Jugador ? (Jugador) userDataA : (Jugador) userDataB;
	        
	        // Activar el estado de ataque del enemigo y aplicar daño al jugador
	        enemigo.setAtacando(true);
	        enemigo.aplicarDaño(jugador); // Aplica daño al jugador
	        jugador.aplicarEmpuje(enemigo.getEmpuje(),enemigo);
	    }
	}

	@Override
	public void postSolve(Contact contact, ContactImpulse impulse) {

	}
}
