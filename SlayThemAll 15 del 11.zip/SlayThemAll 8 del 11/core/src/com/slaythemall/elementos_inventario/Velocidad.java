package com.slaythemall.elementos_inventario;

import com.slaythemall.objetos.Jugador;

public class Velocidad extends Elemento {

	public Velocidad(Jugador jugador) {
		super("Velocidad", 1, TiposElemento.VELOCIDAD, jugador);
	}

}
