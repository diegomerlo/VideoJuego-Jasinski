package com.slaythemall.elementos_inventario;

import com.slaythemall.objetos.Jugador;

public class Ataque extends Elemento {

	public Ataque(Jugador jugador) {
		super("Ataque", 3, TiposElemento.ATAQUE, jugador);
	}

}
