package com.slaythemall.elementos_inventario;

import com.slaythemall.utiles.Recursos;

public enum TiposElementosInventario {
	ANILLO(Recursos.ANILLO_DE_MUERTE, "Reduce impacto de ataques"), ESPADA(Recursos.ESPADA_NOCTURNA, "Aumenta el ataque"), CORAZON(Recursos.CORAZON_DE_PIEDRA, "Una vida extra");
	
	private String direccionImagen, descripcion;
	private TiposElementosInventario(String direccionImagen, String descripcion) {
		this.direccionImagen = direccionImagen;
		this.descripcion = descripcion;
	}
	
	public String getDireccionImagen() {
		return direccionImagen;
	}
	
	public String getDescripcion(){
		return descripcion;
	}
}
