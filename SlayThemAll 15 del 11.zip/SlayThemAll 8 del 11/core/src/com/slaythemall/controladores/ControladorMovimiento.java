package com.slaythemall.controladores;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.math.Vector2;
import com.slaythemall.io.Entradas;
import com.slaythemall.musicas.EfectoSonido;
import com.slaythemall.objetos.Jugador;

public class ControladorMovimiento {
	private Jugador jugador;
	private Entradas entradas;
	private boolean isDashing;
	private float dashSpeed;
	private float dashTime;
	private float dashDuration;
	private int dashCount;
	private final int maxDashes = 2;
	private float dashCooldown;
	private final float dashCooldownDuration = 0.5f; // Duración del tiempo de enfriamiento en segundos
	private float dashBufferTime;
	private final float dashBufferDuration = 0.5f; // Tiempo permitido para realizar el segundo dash
	private boolean hasDashedInAir;
	private boolean tocandoSuelo;
	private boolean puedeDobleSalto;
	private int contadorSalto;

	public ControladorMovimiento(Jugador jugador, Entradas entradas) {
		this.jugador = jugador;
		this.entradas = entradas;
		this.dashSpeed = 1.9f; // La velocidad del dash
		this.dashDuration = 0.4f; // La duración del dash en segundos
		this.isDashing = false;
		this.contadorSalto = 0;
		this.dashCount = 0;
		this.dashCooldown = 0;
		this.dashBufferTime = 0;
		this.hasDashedInAir = false;
		this.tocandoSuelo = false;
		this.puedeDobleSalto = false;
	}

	public void update() {
		float velX = 0;

		if (isDashing) {
			dashTime += Gdx.graphics.getDeltaTime();
			if (dashTime < dashDuration) {
				velX = jugador.isFacingRight() ? dashSpeed : -dashSpeed;
				jugador.getBody().setLinearVelocity(velX * jugador.getVelocidad(), 0); // Establecer velocidad vertical
				EfectoSonido.EFECTO_DASH.playMusic();																	// a 0 durante el dash
			} else {
				isDashing = false;
			}
		} else {
			
			if (entradas.isDerecha()) {
				velX = 1;
			}
			if (entradas.isIzquierda()) {
				velX = -1;
			}
			
			//SOLO REPRODUCE CUANDO ESTA TOCANDO EL SUELO -> MÚSICA
            if((entradas.isDerecha() || entradas.isIzquierda())&&tocandoSuelo) {
            	EfectoSonido.EFECTO_CAMINAR.playMusic();
            }
			
			if (entradas.isDash() && dashCount < maxDashes && dashCooldown <= 0 && !(hasDashedInAir && !tocandoSuelo)) {
				isDashing = true;
				dashTime = 0;
				dashCount++;
				dashBufferTime = dashBufferDuration; // Iniciar el buffer de tiempo para el segundo dash
				if (dashCount == maxDashes) {
					hasDashedInAir = !tocandoSuelo; // Si alcanza el máximo de dashes, establece hasDashedInAir si no
													// está tocando el suelo
					dashCooldown = dashCooldownDuration;
				}
			}
		}

		if (!isDashing && entradas.isSalto() && (isTocandoSuelo() || puedeDobleSalto) && contadorSalto < 2) {
			if (contadorSalto == 1) {
				// Para el segundo salto, establece la velocidad vertical a 0 antes de aplicar
				// el impulso
				jugador.getBody().setLinearVelocity(jugador.getBody().getLinearVelocity().x, 0);
			}
			float fuerza = jugador.getBody().getMass() * 18;
			jugador.getBody().applyLinearImpulse(new Vector2(0, fuerza), jugador.getBody().getPosition(), true);
			contadorSalto++;
			if (!isTocandoSuelo()) {
				puedeDobleSalto = false;
			}
			if (isTocandoSuelo() && jugador.getBody().getLinearVelocity().y == 0) {
				contadorSalto = 0;
			}
			entradas.resetSalto(); // Reiniciar el estado de salto después de aplicarlo
			EfectoSonido.EFECTO_SALTO.playMusic();
		}

		if (!isDashing) {
			jugador.getBody().setLinearVelocity(velX * jugador.getVelocidad(), jugador.getBody().getLinearVelocity().y);
		}

		// Actualizar la dirección del sprite
		if (velX != 0) {
			jugador.setFacingRight(velX > 0);
		}

		if (dashCooldown > 0) {
			dashCooldown -= Gdx.graphics.getDeltaTime();
			if (dashCooldown <= 0) {
				if (tocandoSuelo) {
					dashCount = 0;
				} else {
					dashBufferTime = dashBufferDuration;
				}
			}
		}

		if (dashBufferTime > 0) {
			dashBufferTime -= Gdx.graphics.getDeltaTime();
			if (dashBufferTime <= 0 && dashCount < maxDashes) {
				dashCooldown = dashCooldownDuration;
			}
		}
	}

	public void setTocandoSuelo(boolean tocandoSuelo) {
		this.tocandoSuelo = tocandoSuelo;
		if (tocandoSuelo) {
			puedeDobleSalto = true;
			contadorSalto = 0; // Reiniciar el contador de saltos al tocar el piso
			hasDashedInAir = false; // Reiniciar el boolean de dash en el aire
			dashCount = 0; // Reiniciar el contador de dashes al tocar el piso
		}
	}

	public boolean isTocandoSuelo() {
		return tocandoSuelo;
	}

	public boolean isDashing() {

		return this.isDashing;
	}

	public boolean isWalking() {
		return (entradas.isDerecha() || entradas.isIzquierda()) ? true : false; // Si presiona derecha o izquierda, está
																				// caminando
	}
}
