package com.slaythemall.pantallas;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.slaythemall.elementos.Imagen;
import com.slaythemall.elementos.Texto;
import com.slaythemall.elementos_inventario.TiposElementosInventario;
import com.slaythemall.escenas.HUD;
import com.slaythemall.io.Entradas;
import com.slaythemall.utiles.Config;
import com.slaythemall.utiles.Recursos;
import com.slaythemall.utiles.Render;

public class PantallaInventario implements Screen {

	private static int opcElegido = 0;
	private Entradas entrada = new Entradas();
	Imagen fondo, inventario, contorno;
	Imagen items[] = new Imagen[TiposElementosInventario.values().length];
	SpriteBatch b;
	Stage stage;
	private float itemX[] = new float[items.length];
	private Texto texto;

	public PantallaInventario() {
		fondo = new Imagen(Recursos.FONDO_MENU);
		inventario = new Imagen(Recursos.INVENTARIO_IMAGEN);
		inventario.setSize((Config.ANCHO / 4) * 3, (Config.ALTO / 4) * 3);
		contorno = new Imagen(Recursos.CONTORNO_PERSONAJE_ELECCION);
		contorno.setSize(60, 60);
		
		

		stage = new Stage(new ScreenViewport());
		InputMultiplexer multiplexer = new InputMultiplexer();
		multiplexer.addProcessor(stage);
		multiplexer.addProcessor(entrada);
		Gdx.input.setInputProcessor(multiplexer);
		
		texto = new Texto(Recursos.FUENTE_MENU, 50, Color.WHITE, true);
		texto.setPosicion(Config.ANCHO / 2 - inventario.getAncho()/2, Config.ALTO / 2 -inventario.getAlto()/2 +20);


		for (int i = 0; i < items.length; i++) {
			items[i] = new Imagen(TiposElementosInventario.values()[i].getDireccionImagen());
			items[i].setSize(58, 53);
		}

		int valoresX = -299;

		for (int i = 0; i < items.length; i++) {
			itemX[i] = Config.ANCHO / 2 + valoresX;
			valoresX += 77;
		}

		b = Render.batch;
	}

	@Override
	public void show() {
	}

	@Override
	public void render(float delta) {

		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		b.begin();
		fondo.dibujar();
		inventario.dibujar(Config.ANCHO / 2 - inventario.getAncho() / 2, Config.ALTO / 2 - inventario.getAlto() / 2);
		texto.setTexto(TiposElementosInventario.values()[opcElegido].getDescripcion());
		texto.dibujar();
		
		for (int i = 0; i < items.length; i++) {
			items[i].dibujar(itemX[i]+3, Config.ALTO / 2 + 78);
		}

		contorno.dibujar(itemX[opcElegido] +(2.5f), Config.ALTO / 2 + 80 -5);
		
		b.end();

		if (entrada.isIzquierda()) {
            opcElegido = (opcElegido - 1 + items.length) % items.length;
            entrada.resetMoverIzquierda(); // Evitar movimiento múltiple con una sola pulsación
        }

        if (entrada.isDerecha()) {
            opcElegido = (opcElegido + 1) % items.length;
            entrada.resetMoverDerecha(); // Evitar movimiento múltiple con una sola pulsación
        }

        // Aquí podrías implementar lo que ocurre al presionar "Enter" o "Esc"
        if (entrada.isEnter()) {
            HUD.setElementoInventario(TiposElementosInventario.values()[opcElegido]);
            Render.app.setScreen(new PantallaJuego());
        }
	}

	@Override
	public void resize(int width, int height) {
		// No necesitamos hacer nada aquí por ahora
	}

	@Override
	public void pause() {
		// Aquí puedes pausar cualquier actividad si es necesario
	}

	@Override
	public void resume() {
		// Aquí puedes reanudar actividades si es necesario
	}

	@Override
	public void hide() {
		// Aquí puedes manejar la ocultación de la pantalla si es necesario
	}

	@Override
	public void dispose() {
//        // Limpiar recursos cuando la pantalla ya no se usa
//        fondo.dispose();
//        inventario.dispose();
//        item1.dispose();
//        item2.dispose();
//        item3.dispose();
	}
}
