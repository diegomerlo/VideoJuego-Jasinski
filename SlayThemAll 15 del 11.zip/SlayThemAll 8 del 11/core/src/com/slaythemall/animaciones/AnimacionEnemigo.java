package com.slaythemall.animaciones;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.slaythemall.objetos.Estados;
import java.util.HashMap;

import java.util.Map;

public class AnimacionEnemigo extends Animacion {
    private Map<Estados, Animation<TextureRegion>> animaciones;

    public AnimacionEnemigo(TextureAtlas atlas, Map<Estados, AnimacionConfig> configuracionesAnimacion) {
        super(atlas);
        animaciones = crearAnimaciones(configuracionesAnimacion);
    }

    private Map<Estados, Animation<TextureRegion>> crearAnimaciones(Map<Estados, AnimacionConfig> configuracionesAnimacion) {
        Map<Estados, Animation<TextureRegion>> animMap = new HashMap<>();
        for (Map.Entry<Estados, AnimacionConfig> entry : configuracionesAnimacion.entrySet()) {
            Estados estado = entry.getKey();
            AnimacionConfig config = entry.getValue();
            animMap.put(estado, createAnimation(config.getRegionName(), config.getNumFrames(), config.getFrameDuration()));
        }
        return animMap;
    }

    @Override
    public TextureRegion getFrame(Estados estadoActual, float deltaTime) {
        stateTime += deltaTime;
        return animaciones.getOrDefault(estadoActual, animaciones.get(Estados.IDLE)).getKeyFrame(stateTime, true);
    }

    public boolean isRecibirGolpeAnimationFinished() {
        return animaciones.get(Estados.RECIBIR_GOLPE).isAnimationFinished(stateTime);
    }
   
    public boolean isAttackAnimationFinished() {
    	return animaciones.get(Estados.ATACAR).isAnimationFinished(stateTime);
    }

    public void resetStateTime() {
        stateTime = 0f;
    }
}
