package com.slaythemall.utiles;

public class Recursos {
	// FONDOS
	public final static String PRUEBA_IMAGEN = "fondos/desarrolladores.png";
	public final static String FONDO_MENU = "fondos/fondoMenuInicio.png";
	public final static String FONDO_WIN = "fondos/fondoWin.png";

	// FUENTES
	public final static String FUENTE_MENU = "fuentes/Crang.ttf";

	// MUSICAS
	public final static String MUSICA_FONDO_NIVEL_1 = "musica/musicaAmbiente/electroMusic.mp3";

	// EFECTOS DE SONIDO
	public final static String EFECTO_SONIDO_CAMINAR = "musica/efectoSonido/caminar.mp3";
	public final static String EFECTO_SONIDO_SALTAR = "musica/efectoSonido/saltar.mp3";
	public final static String EFECTO_SONIDO_DASH = "musica/efectoSonido/rafagaViento.mp3";
	public final static String EFECTO_SONIDO_ESPADA_BASICO = "musica/efectoSonido/efectoEspada.mp3";

	// ATLAS ANIMACIONES
	public final static String ANIMACIONES_JUGADOR = "animacionesJugador/movimientosJugador.txt";
	public final static String ANIMACIONES_ENEMIGO1 = "animacionesEnemigo/movimientosEnemigo1.txt";

	// ELEMENTOS MENU
	public final static String SLIDER_BACKGROUND = "elementosMenu/slider_background.png";
	public final static String SLIDER_KNOB = "elementosMenu/slider_knob.png";
	public final static String FLECHA_ATRAS = "elementosMenu/flecha_atras.png";

}
