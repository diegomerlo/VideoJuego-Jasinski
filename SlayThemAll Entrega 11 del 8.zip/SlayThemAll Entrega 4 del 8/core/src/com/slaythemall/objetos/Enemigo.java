package com.slaythemall.objetos;

import static com.slaythemall.utiles.Constantes.PPM;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.physics.box2d.Body;
import com.slaythemall.animaciones.AnimacionEnemigo;
import com.slaythemall.utiles.Recursos;

public class Enemigo extends GameEntity {
	private AnimacionEnemigo animacionEnemigo;
	private Estados estadoEnemigo;

	public Enemigo(float ancho, float alto, Body body) {
		super(ancho, alto, body);
		this.animacionEnemigo = new AnimacionEnemigo(
				new TextureAtlas(Gdx.files.internal(Recursos.ANIMACIONES_ENEMIGO1)));
		this.estadoEnemigo = Estados.IDLE;
		this.vida = 30; // Vida inicial del enemigo
		this.body.setUserData(this);
	}

	@Override
	public void update() {
		if (this.vida <= 0) {
			morir();
			return;
		}

		x = body.getPosition().x * PPM;
		y = body.getPosition().y * PPM;

		// Comprobar si la animación de recibir golpe ha terminado
		if (estadoEnemigo == Estados.RECIBIR_GOLPE && animacionEnemigo.isRecibirGolpeAnimationFinished()) {
			estadoEnemigo = Estados.IDLE;
		}
	}

	@Override
	public void render(SpriteBatch batch) {
		if (this.vida > 0) {
			TextureRegion currentFrame = animacionEnemigo.getFrame(estadoEnemigo, Gdx.graphics.getDeltaTime());

			if (currentFrame != null) {
				batch.draw(currentFrame, x - ancho / 2, y - alto / 2, ancho, alto);
			}
		}
	}

	public void recibirGolpe(float daño) {
		this.vida -= daño;
		System.out.println("AY ME PEGO");
		if (this.vida <= 0) {
			System.out.println("AY ME MUERO");
		}
		estadoEnemigo = Estados.RECIBIR_GOLPE;
		animacionEnemigo.resetStateTime(); // Reiniciar el tiempo de estado de la animación
	}

	public void resetearEstado() {
		estadoEnemigo = Estados.IDLE;
	}

	public Estados getEstadoEnemigo() {
		return estadoEnemigo;
	}

	private void morir() {
		if (body != null) {
			// Eliminar el cuerpo del mundo físico
			body.getWorld().destroyBody(body);
			body = null; // Asegurarse de que el cuerpo se elimine completamente
		}
	}

	public int getVida() {
		return this.vida;
	}
}
