package com.slaythemall.pantallas;

import static com.slaythemall.utiles.Constantes.PPM;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.slaythemall.colisiones.ContactListenerImpl;
import com.slaythemall.escenas.HUD;
import com.slaythemall.mapas.TiledMaps;
import com.slaythemall.objetos.Enemigo;
import com.slaythemall.objetos.Jugador;
import com.slaythemall.utiles.Config;
import com.slaythemall.utiles.Render;

public class PantallaJuego extends ScreenAdapter {

	private OrthographicCamera camara;
	private Viewport viewport;
	private SpriteBatch batch;
	private World mundo;
	private Box2DDebugRenderer box2DDebugRenderer;
	private OrthogonalTiledMapRenderer orthogonalTiledMapRenderer;
	private TiledMaps tiledMaps;
	private Jugador jugador;
	private Enemigo[] enemigos;
	private HUD hud;
	private Stage stage;
    private ImageButton backButton;
    private boolean juegoPausado = false;
    private PantallaPausa pantallaPausa;
    private boolean finJuego = false;


	public PantallaJuego() {
		// Configura la cámara y el viewport
		this.camara = new OrthographicCamera();
		this.viewport = new FitViewport(Config.ANCHO, Config.ALTO, camara);
		this.camara.setToOrtho(false, Config.ANCHO, Config.ALTO);
		this.batch = new SpriteBatch();
		this.mundo = new World(new Vector2(0, -25f), false);
		this.box2DDebugRenderer = new Box2DDebugRenderer();
		this.tiledMaps = new TiledMaps(this);
		this.orthogonalTiledMapRenderer = tiledMaps.iniciarMapa();
		mundo.setContactListener(new ContactListenerImpl());
		this.hud = new HUD(this.batch);
		this.stage = new Stage(new ScreenViewport(), batch);
	}

	private void update() {
		mundo.step(1 / 60f, 6, 2);
		camaraActualizar();
		viewport.apply(); // Aplica los cambios del viewport
		batch.setProjectionMatrix(camara.combined);
		orthogonalTiledMapRenderer.setView(camara);
		jugador.update();
		jugador.actualizarSensorEspada();

		hudUpdate(Gdx.graphics.getDeltaTime());

		
		// Actualizar enemigos y eliminar los muertos
		for (int i = 0; i < enemigos.length; i++) {
			if (enemigos[i] != null) {
				enemigos[i].update();
				if (enemigos[i].getVida() <= 0) {
					enemigos[i] = null; // Eliminar el enemigo de la lista
					finJuego=true;
				}
			}
		}
		if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
			Render.app.setScreen(new PantallaMenu());
		}
		if(finJuego) {
			Render.app.setScreen(new PantallaGameWin());
		}
	}

	private void camaraActualizar() {
		Vector3 position = camara.position;
		position.x = Math.round(jugador.getBody().getPosition().x * PPM * 10) / 10f;
		position.y = (40) + Math.round(jugador.getBody().getPosition().y * PPM * 10) / 10f;
		camara.position.set(position);
		camara.update();
	}

	private void hudUpdate(float delta) {
		hud.setContadorTiempo(hud.getContadorTiempo() + delta);
		if (hud.getContadorTiempo() >= 1) {
			hud.setTiempo(hud.getTiempo() + 1);
			hud.getContadorLabel().setText(String.format("%03d", hud.getTiempo()));
			hud.setContadorTiempo(0);
		}
	}

	@Override
	public void render(float delta) {
		if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
	        if (juegoPausado) {
	            Render.app.setScreen(this); // Volver a la pantalla del juego
	        } else {
	            Render.app.setScreen(new PantallaPausa(this)); // Mostrar pantalla de pausa
	        }
	        juegoPausado = !juegoPausado;
	    }

	    if (!juegoPausado) {
	        this.update(); // Solo actualiza si el juego no está pausado
	    }
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		orthogonalTiledMapRenderer.render();
		batch.setProjectionMatrix(camara.combined);
		batch.begin();
		this.camara.zoom = 0.7f;//
		jugador.render(batch);

		for (Enemigo enemigo : enemigos) {
			if (enemigo != null) {
				enemigo.update();
				enemigo.render(batch);
			}
		}

		batch.end();
//		box2DDebugRenderer.render(mundo, camara.combined.scl(PPM)); // Para dibujar las hitbox
		batch.setProjectionMatrix(hud.stage.getCamera().combined);
		hud.stage.draw();
	}

	@Override
	public void dispose() {
		// Dispose de cada uno de los componentes utilizados
		batch.dispose();
		mundo.dispose();
		box2DDebugRenderer.dispose();
		orthogonalTiledMapRenderer.dispose();
		tiledMaps.dispose();
	}

	public void resize(int width, int height) {
		viewport.update(width, height, true);
	}

	public World getMundo() {
		return mundo;
	}

	public SpriteBatch getBatch() {
		return batch;
	}
	
	public void setJugador(Jugador jugador) {
		this.jugador = jugador;
	}

	public void setEnemigos(Enemigo[] enemigos) {
		this.enemigos = enemigos;
	}

	public void setPausado(boolean pausado) {
	    this.juegoPausado = pausado;
	    if (pausado) {
	        mundo.setGravity(new Vector2(0, 0)); // Desactivar la gravedad
	        Gdx.input.setInputProcessor(null); // Desactivar el procesador de entrada
	    } else {
	        mundo.setGravity(new Vector2(0, -25f)); // Restaurar la gravedad
	        configurarInputProcessor(); // Volver a configurar el procesador de entrada
	        jugador.resetEntradas(); // Resetear las entradas para evitar estados incorrectos
	    }
	}

	private void configurarInputProcessor() {
	    Gdx.input.setInputProcessor(jugador.getEntradas()); // Configurar el procesador de entradas del jugador
	}

	
	public Jugador getJugador() {
		return this.jugador;
	}
}
