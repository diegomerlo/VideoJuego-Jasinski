package com.slaythemall.pantallas;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputMultiplexer;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.slaythemall.elementos.Imagen;
import com.slaythemall.elementos.Texto;
import com.slaythemall.io.Entradas;
import com.slaythemall.utiles.Config;
import com.slaythemall.utiles.Recursos;
import com.slaythemall.utiles.Render;

public class PantallaComoJugar implements Screen {

	private Imagen fondo;
	private SpriteBatch b;
	private Stage stage;
	private Texto textos[] = new Texto[6];
	private ImageButton backButton;
	private Entradas entrada = new Entradas();

	@Override
	public void show() {
		// Cargar el fondo del menú
		fondo = new Imagen(Recursos.FONDO_MENU);
		b = Render.batch;

		// Configurar el escenario
		stage = new Stage(new ScreenViewport());

		InputMultiplexer multiplexer = new InputMultiplexer();
	    multiplexer.addProcessor(stage);   // Añadir el procesador del stage
	    multiplexer.addProcessor(entrada); // Añadir tu procesador de entradas personal
	    Gdx.input.setInputProcessor(multiplexer);
	    
		int posiscionY = 50;
		int inicioY = 150;
		
		// --------Texto SALTO ------
		textos[0] = new Texto(Recursos.FUENTE_MENU, 30, Color.WHITE, false);
		textos[0].setTexto("SALTAR: C");
		textos[0].setPosicion((Config.ANCHO / 2) - (textos[0].getAncho() / 2), Config.ALTO - posiscionY - inicioY);

		// --------Texto ATACAR ------
		textos[1] = new Texto(Recursos.FUENTE_MENU, 30, Color.WHITE, false);
		textos[1].setTexto("ATACAR: X");
		textos[1].setPosicion((Config.ANCHO / 2) - (textos[1].getAncho() / 2), Config.ALTO - posiscionY * 2 - inicioY);

		// --------Texto DASH ------
		textos[2] = new Texto(Recursos.FUENTE_MENU, 30, Color.WHITE, false);
		textos[2].setTexto("DASH: Z");
		textos[2].setPosicion((Config.ANCHO / 2) - (textos[1].getAncho() / 2), Config.ALTO - posiscionY * 3 - inicioY);

		// --------Texto DERECHA ------
		textos[3] = new Texto(Recursos.FUENTE_MENU, 30, Color.WHITE, false);
		textos[3].setTexto("Derecha: ->");
		textos[3].setPosicion((Config.ANCHO / 2) - (textos[1].getAncho() / 2), Config.ALTO - posiscionY * 4 - inicioY);

		// --------Texto IZQUIERDA ------
		textos[4] = new Texto(Recursos.FUENTE_MENU, 30, Color.WHITE, false);
		textos[4].setTexto("IZQUIERDA: <-");
		textos[4].setPosicion((Config.ANCHO / 2) - (textos[1].getAncho() / 2), Config.ALTO - posiscionY * 5 - inicioY);
		
		// --------Texto EXIT ------
		textos[5] = new Texto(Recursos.FUENTE_MENU, 30, Color.WHITE, false);
		textos[5].setTexto("SALIR: ESC");
		textos[5].setPosicion((Config.ANCHO / 2) - (textos[1].getAncho() / 2), Config.ALTO - posiscionY * 6 - inicioY);

		// --------Botón de regreso (flecha) ------
		// Cargar la textura de la flecha
		Texture backTexture = new Texture(Gdx.files.internal(Recursos.FLECHA_ATRAS));
		Drawable backDrawable = new TextureRegionDrawable(backTexture);

		// Crear el botón de imagen con la textura de la flecha
		backButton = new ImageButton(backDrawable);

		// Posicionar el botón en la esquina superior izquierda
		backButton.setSize(50, 50);
		backButton.setPosition(20, Config.ALTO - backButton.getHeight() - 20);

		// Añadir listener para regresar al menú
		backButton.addListener(new ClickListener() {
			@Override
			public void clicked(InputEvent event, float x, float y) {
				// Cambiar de pantalla al menú principal
				Render.app.setScreen(new PantallaMenu());
			}
		});

		stage.addActor(backButton);
	}

	@Override
	public void render(float delta) {
		// Limpiar la pantalla
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		// Dibujar el fondo y el escenario
		b.begin();
			fondo.dibujar();
			textos[0].dibujar();
			textos[1].dibujar();
			textos[2].dibujar();
			textos[3].dibujar();
			textos[4].dibujar();
			textos[5].dibujar();
		b.end();
		
		if(entrada.isEscape()) {
			Render.app.setScreen(new PantallaMenu());
		}

		stage.act(delta);
		stage.draw();
	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub
		stage.getViewport().update(width, height, true);
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	@Override
	public void hide() {
		// TODO Auto-generated method stub

	}

	@Override
	public void dispose() {
		// Liberar recursos
		stage.dispose();
	}

}
