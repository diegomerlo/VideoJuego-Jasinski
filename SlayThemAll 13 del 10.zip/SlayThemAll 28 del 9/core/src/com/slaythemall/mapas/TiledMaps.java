package com.slaythemall.mapas;

import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.MapObjects;
import com.badlogic.gdx.maps.objects.PolygonMapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.Shape;
import com.slaythemall.objetos.Enemigo;
import com.slaythemall.objetos.Jugador;
import com.slaythemall.objetos.TipoJugador;
import com.slaythemall.pantallas.PantallaJuego;
import com.slaythemall.utiles.BodyImpl;
import com.badlogic.gdx.math.Vector2;

import static com.slaythemall.utiles.Constantes.PPM;

import java.util.HashMap;
import java.util.Map;

public class TiledMaps {

	private PantallaJuego pantallaJuego;
	private Enemigo[] enemigos;
	private int enemigoIndex;
	private Map<String, Boolean> objetosCreado;
	public TiledMaps(PantallaJuego pantallaJuego) {
		this.pantallaJuego = pantallaJuego;
		this.objetosCreado = new HashMap<>();
		objetosCreado.put("jugador", false);
		objetosCreado.put("sensorPies", false);
		objetosCreado.put("sensorEspada", false);
	}

	public void iniciarMapa(TiledMap tiledMap) {
		int numEnemigos = contarEnemigos(tiledMap.getLayers().get("objetos").getObjects());
		enemigos = new Enemigo[numEnemigos];
		enemigoIndex = 0;
		parseMapObjects(tiledMap.getLayers().get("objetos").getObjects());
		pantallaJuego.setEnemigos(enemigos);
	}

	private int contarEnemigos(MapObjects mapObjects) {
		int count = 0;
		for (MapObject mapObject : mapObjects) {
			if (mapObject instanceof RectangleMapObject) {
				String rectangleName = mapObject.getName();
				if (rectangleName.equals("enemigo")) {
					count++;
				}
			}
		}
		return count;
	}

	private void parseMapObjects(MapObjects mapObjects) {
		for (MapObject mapObject : mapObjects) {
			if (mapObject instanceof PolygonMapObject) {
				crearCuerpoEstatico((PolygonMapObject) mapObject);
			} else if (mapObject instanceof RectangleMapObject) {
				procesarRectangleMapObject((RectangleMapObject) mapObject);
			}
		}
	}

	private void procesarRectangleMapObject(RectangleMapObject rectangleMapObject) {
		Rectangle rectangle = rectangleMapObject.getRectangle();
		String rectangleName = rectangleMapObject.getName();
		switch (rectangleName) {
		case "jugador":
			if (!objetosCreado.get("jugador")) {
				crearJugador(rectangle);
				objetosCreado.put("jugador", true);
			}
			break;
		case "sensorPies":
			if (!objetosCreado.get("sensorPies")) {
				agregarSensorPies(rectangle);
				objetosCreado.put("sensorPies", true);
			}
			break;
		case "sensorEspada":
			if (!objetosCreado.get("sensorEspada")) {
				agregarSensorEspada(rectangle);
				objetosCreado.put("sensorEspada", true);
			}
			break;
		case "enemigo":
			crearEnemigo(rectangle);
			break;

		  case "posicionInicial":
	            // Almacena las coordenadas de la posición inicial
			  calcularPosicionInicial(rectangle);
	            break;

		default:
			// Manejo opcional para otros nombres de rectángulos
			break;
		}

	}

	private void calcularPosicionInicial(Rectangle rectangle) {
		pantallaJuego.setPosicionInicial(new Vector2(
			        (rectangle.getX() + rectangle.getWidth() / 2) / PPM,  
			        (rectangle.getY() + rectangle.getHeight() / 2) / PPM  
			    ));
	}

	 private void crearJugador(Rectangle rectangle) {    
	        Body body = BodyImpl.createBody(rectangle.getX() + rectangle.getWidth() / 2,
	                rectangle.getY() + rectangle.getHeight() / 2, rectangle.getWidth(), rectangle.getHeight(), false,
	                pantallaJuego.getMundo());

	        // Usamos el enum Jugadores y reflection para instanciar el personaje
	        Jugador jugador = TipoJugador.obtenerPersonaje(0, rectangle.getWidth(), rectangle.getHeight(), body);
	        pantallaJuego.setJugador(jugador);  // Asignamos el jugador creado a la pantalla
	    }

	private void agregarSensorPies(Rectangle rectangle) {
		BodyImpl.agregarFootSensor(pantallaJuego.getJugador().getBody(), rectangle);
	}

	private void agregarSensorEspada(Rectangle rectangle) {
		Fixture sensorEspada = BodyImpl.crearSensorEspada(pantallaJuego.getJugador().getBody(), rectangle);
		pantallaJuego.getJugador().configurarSensorEspada(sensorEspada, rectangle.getWidth(), rectangle.getHeight());
	}

	private void crearEnemigo(Rectangle rectangle) {
		Body body = BodyImpl.createBody(rectangle.getX() + rectangle.getWidth() / 2,
				rectangle.getY() + rectangle.getHeight() / 2, rectangle.getWidth(), rectangle.getHeight(), true,
				pantallaJuego.getMundo());
		enemigos[enemigoIndex++] = new Enemigo(rectangle.getWidth(), rectangle.getHeight(), body);
	}

	private void crearCuerpoEstatico(PolygonMapObject polygonMapObject) {
		BodyDef bodyDef = new BodyDef();
		bodyDef.type = BodyDef.BodyType.StaticBody;
		Body body = pantallaJuego.getMundo().createBody(bodyDef);
		Shape shape = createPolygonShape(polygonMapObject);
		body.createFixture(shape, 1000);
		shape.dispose();
	}

	private Shape createPolygonShape(PolygonMapObject polygonMapObject) {
		float[] vertices = polygonMapObject.getPolygon().getTransformedVertices();
		Vector2[] worldVertices = new Vector2[vertices.length / 2];
		for (int i = 0; i < vertices.length / 2; i++) {
			Vector2 current = new Vector2(vertices[i * 2] / PPM, vertices[i * 2 + 1] / PPM);
			worldVertices[i] = current;
		}
		PolygonShape shape = new PolygonShape();
		shape.set(worldVertices);
		return shape;
	}

	public void dispose() {
		// No es necesario disponer del mapa aquí, ya que lo maneja GestorMapas
	}

	public void eliminarCuerposEnemigos() {
		for (int i = 0; i < enemigos.length; i++) {
			if (enemigos[i] != null) {
				enemigos[i].eliminarCuerpoEnemigo(); // Llamamos al método que destruye el cuerpo
				enemigos[i] = null; // Luego eliminamos el enemigo del array
			}
		}
	}
}
