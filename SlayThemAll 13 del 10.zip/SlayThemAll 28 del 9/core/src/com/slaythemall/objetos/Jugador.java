// Paquete de objetos
package com.slaythemall.objetos;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.slaythemall.controladores.ControladorAtaque;
import com.slaythemall.controladores.ControladorMovimiento;
import com.slaythemall.utiles.Recursos;
import com.slaythemall.utiles.Utiles;
import com.slaythemall.animaciones.AnimacionJugador;
import com.slaythemall.io.Entradas;

import static com.slaythemall.utiles.Constantes.PPM;

public abstract class Jugador extends GameEntity {
    protected EstadoJugador estadoJugador;
    protected AnimacionJugador animacionJugador;
    protected TextureAtlas atlas;
    protected float stateTime;
    protected boolean isFacingRight;
    protected Entradas entradas;
    protected ControladorAtaque controladorAtaque;
    protected ControladorMovimiento controladorMovimiento;
    protected float daño;

    public Jugador(float ancho, float alto, Body body, String atlasPath, float daño) {
        super(ancho, alto, body);
        this.velocidad = 10f;
        this.atlas = new TextureAtlas(Gdx.files.internal(atlasPath));
        this.estadoJugador = new EstadoJugador();
        this.animacionJugador = new AnimacionJugador(atlas);
        this.stateTime = 0f;
        this.isFacingRight = true;
        this.entradas = new Entradas();
        this.body = body;
        this.body.setUserData(this);
        this.daño = daño;

        this.controladorAtaque = new ControladorAtaque(this);
        this.controladorMovimiento = new ControladorMovimiento(this, entradas);
        Gdx.input.setInputProcessor(entradas);
    }

    @Override
    public void update() {
        x = body.getPosition().x * PPM;
        y = body.getPosition().y * PPM;

        verificarEntradaDeUsuario();
        estadoJugador.actualizarEstado(this);

        controladorAtaque.update();
        controladorMovimiento.update();
    }

    @Override
    public void render(SpriteBatch batch) {
        TextureRegion currentFrame = animacionJugador.getFrame(estadoJugador.getEstadoActual(),
                Gdx.graphics.getDeltaTime());
        float offSetXDerecha = 4;
        float offSetIzquierda = (offSetXDerecha * 7);
        float offSetWidth = 11;
        if (currentFrame != null) {
            if (!isFacingRight) {
                batch.draw(currentFrame, x - ancho + offSetIzquierda / 2 + ancho, y - alto / 2, -ancho - offSetWidth,
                        alto);
            } else {
                batch.draw(currentFrame, x - ancho + offSetXDerecha / 2, y - alto / 2, ancho + offSetWidth, alto);
            }
        }
    }

    public void setTocandoSuelo(boolean tocandoSuelo) {
        controladorMovimiento.setTocandoSuelo(tocandoSuelo);
    }

    public boolean isTocandoSuelo() {
        return controladorMovimiento.isTocandoSuelo();
    }

    private void verificarEntradaDeUsuario() {
        velX = 0;

        if (entradas.isAtacar() && controladorAtaque.canAttack()) {
            controladorAtaque.attack();
            entradas.resetAtacar();
        }
    }

    public boolean isJumping() {
        return body.getLinearVelocity().y > 0;
    }

    public boolean isFalling() {
        return body.getLinearVelocity().y < 0;
    }

    public boolean isWalking() {
        return controladorMovimiento.isWalking();
    }

    public void resetStateTime() {
        stateTime = 0f;
    }

    public float getVelX() {
        return velX;
    }

    public boolean isDashing() {
        return controladorMovimiento.isDashing();
    }

    public boolean isAttacking() {
        return controladorAtaque.isAttacking();
    }

    public float getDaño() {
        return daño;
    }

    public void setEnemyContact(Enemigo enemigo) {
        controladorAtaque.setEnemyContact(enemigo);
    }

    public void configurarSensorEspada(Fixture sensorEspada, float width, float height) {
        controladorAtaque.setSensorEspada(sensorEspada);
        controladorAtaque.setEspadaDimensiones(width, height);
    }

    public void actualizarSensorEspada() {
        controladorAtaque.actualizarSensorEspada(isFacingRight);
    }

    public boolean isFacingRight() {
        return this.isFacingRight;
    }

    public void setFacingRight(boolean isFacingRight) {
        this.isFacingRight = isFacingRight;
    }

    public float getVelocidad() {
        return this.velocidad;
    }

    public void reiniciarPosicionInicial(Vector2 posicion) {
        this.getBody().setTransform(posicion.x, posicion.y, getBody().getAngle());
    }

    public void resetEntradas() {
        entradas.resetMoverDerecha();
        entradas.resetMoverIzquierda();
        entradas.resetAtacar();
        entradas.resetSaltar();
        entradas.resetDash();
    }

    public Entradas getEntradas() {
        return this.entradas;
    }
  
}
