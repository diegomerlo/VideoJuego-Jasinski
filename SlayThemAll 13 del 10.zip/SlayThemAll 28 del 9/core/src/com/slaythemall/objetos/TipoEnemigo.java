package com.slaythemall.objetos;

import java.lang.reflect.InvocationTargetException;

import com.badlogic.gdx.physics.box2d.Body;


public enum TipoEnemigo {

	TRAINING_DUMMY("TrainingDummy", "com.slaythemall.objetos.TrainingDummy");

    private String nombre;
    private String nombreClase;

    TipoEnemigo(String nombre, String nombreClase) {
        this.nombre = nombre;
        this.nombreClase = nombreClase;
    }

    public String getNombre() {
        return nombre;
    }

    public String getNombreClase() {
        return nombreClase;
    }
	
    public static Enemigo obtenerEnemigo(int opc, float ancho, float alto, Body body) {
        Enemigo enemigo = null;
		
			try {
			Class clase = Class.forName(values()[opc].getNombreClase());
			enemigo = (Enemigo) clase.getDeclaredConstructor(float.class, float.class, Body.class).newInstance(ancho, alto, body);
			} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | NoSuchMethodException | SecurityException e) {
				e.printStackTrace();
			}
		return enemigo;
	}
}
