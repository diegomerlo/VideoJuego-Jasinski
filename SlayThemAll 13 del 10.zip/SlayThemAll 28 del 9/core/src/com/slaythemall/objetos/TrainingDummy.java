/*package com.slaythemall.objetos;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.physics.box2d.Body;
import com.slaythemall.animaciones.AnimacionEnemigo;
import com.slaythemall.utiles.Recursos;

public class TrainingDummy extends Enemigo {

	public TrainingDummy(float ancho, float alto, Body body) {
		super(ancho, alto, body, new AnimacionEnemigo(new TextureAtlas(Gdx.files.internal(Recursos.ANIMACIONES_ENEMIGO1))));
	}
}*/