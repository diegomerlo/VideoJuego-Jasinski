package com.slaythemall.objetos;

import com.badlogic.gdx.physics.box2d.Body;
import com.slaythemall.utiles.Recursos;

public class Samurai extends Jugador {

    public static final String ATLAS_PATH = Recursos.ANIMACIONES_SAMURAI;
    public static final float DAÑO = 50f;

    public Samurai(float ancho, float alto, Body body) {
        super(ancho, alto, body, ATLAS_PATH, DAÑO);
    }
}
