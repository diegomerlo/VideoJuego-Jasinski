package com.slaythemall.utiles;

public class Constantes {

	public static final float PPM = 32.0f;

}
