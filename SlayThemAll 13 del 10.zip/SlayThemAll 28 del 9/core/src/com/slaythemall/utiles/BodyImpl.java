package com.slaythemall.utiles;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import static com.slaythemall.utiles.Constantes.PPM;

public class BodyImpl {

	public static Body createBody(float x, float y, float ancho, float alto, boolean isStatic, World world) {
		BodyDef bodyDef = new BodyDef();
		bodyDef.type = isStatic ? BodyDef.BodyType.StaticBody : BodyDef.BodyType.DynamicBody;
		bodyDef.position.set(x / PPM, y / PPM);
		bodyDef.fixedRotation = true;
		Body body = world.createBody(bodyDef);

		PolygonShape shape = new PolygonShape();
		shape.setAsBox(ancho / 2 / PPM, alto / 2 / PPM);

		FixtureDef fixtureDef = new FixtureDef();
		fixtureDef.shape = shape;
		fixtureDef.friction = 0;
		body.createFixture(fixtureDef);
		shape.dispose();

		return body;
	}

	public static void agregarFootSensor(Body body, Rectangle rectangle) {
		PolygonShape footShape = new PolygonShape();
		float footSensorHeight = 5 / PPM; // Altura del foot sensor
		float extraOffset = 6 / PPM; // Ajuste adicional para bajar más el sensor
		float offsetY = -rectangle.getHeight() / 2 / PPM - footSensorHeight - extraOffset; // Desplazamiento en Y
																							// aumentado
		footShape.setAsBox(rectangle.getWidth() / 2 / PPM, footSensorHeight, new Vector2(0, offsetY), 0);
		FixtureDef footFixtureDef = new FixtureDef();
		footFixtureDef.shape = footShape;
		footFixtureDef.isSensor = true;
		Fixture footSensor = body.createFixture(footFixtureDef);
		footSensor.setUserData("sensorPies");
		footShape.dispose();
	}

	public static Fixture crearSensorEspada(Body body, Rectangle rectangle) {
	    PolygonShape espadaShape = new PolygonShape();
	    float width = rectangle.getWidth() / 2 / PPM;
	    float height = rectangle.getHeight() / 2 / PPM;

	    espadaShape.setAsBox(width, height);

	    FixtureDef espadaFixtureDef = new FixtureDef();
	    espadaFixtureDef.shape = espadaShape;
	    espadaFixtureDef.isSensor = true;

	    Fixture espadaSensor = body.createFixture(espadaFixtureDef);
	    espadaSensor.setUserData("sensorEspada");

	    espadaShape.dispose();

	    return espadaSensor;
	}


}
