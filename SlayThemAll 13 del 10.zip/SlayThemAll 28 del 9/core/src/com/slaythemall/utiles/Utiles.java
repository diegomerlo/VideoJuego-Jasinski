package com.slaythemall.utiles;

import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public final class Utiles {
	
	public static Scanner s = new Scanner(System.in);
	public static Random r = new Random();
	
	public static int ingresarEntero(int min,int max) {
		boolean error = false;
		int opc = 0;
		do {
			error = false;
			try {
			opc = s.nextInt();
			s.nextLine();
			if(opc<min || opc>max) {
				error = true;
				System.out.println("Debe ingresar un número entre " + min + " y " + max);
			}
			} catch(InputMismatchException e) {
				error = true;
				s.nextLine();
				System.out.println("Error. Debe ingreesar un número");
			} catch(Exception e) {
				error = true;
				System.out.println("Error desconocido");
			}
		}while(error);
		return opc;
	}
	
	public static void esperar(int milis) {
		try {
			Thread.sleep(milis);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}