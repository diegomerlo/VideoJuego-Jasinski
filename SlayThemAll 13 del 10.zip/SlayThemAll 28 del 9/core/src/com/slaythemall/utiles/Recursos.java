package com.slaythemall.utiles;

public class Recursos {
	// FONDOS
	public final static String PRUEBA_IMAGEN = "fondos/desarrolladores.png";
	public final static String FONDO_MENU = "fondos/fondoMenuInicio.png";
	public final static String FONDO_WIN = "fondos/fondoWin.png";

	// FUENTES
	public final static String FUENTE_MENU = "fuentes/Crang.ttf";

	// MUSICAS
	public final static String MUSICA_FONDO_NIVEL_1 = "musica/musicaAmbiente/electroMusic.mp3";

	// EFECTOS DE SONIDO
	public final static String EFECTO_SONIDO_CAMINAR = "musica/efectoSonido/caminar.mp3";
	public final static String EFECTO_SONIDO_SALTAR = "musica/efectoSonido/saltar.mp3";
	public final static String EFECTO_SONIDO_DASH = "musica/efectoSonido/rafagaViento.mp3";
	public final static String EFECTO_SONIDO_ESPADA_BASICO = "musica/efectoSonido/efectoEspada.mp3";

	// ATLAS ANIMACIONES
	public final static String ANIMACIONES_SAMURAI = "animacionesSamurai/movimientosSamurai.txt";
	public final static String ANIMACIONES_ENEMIGO1 = "animacionesEnemigo/movimientosEnemigo1.txt";

	// ELEMENTOS MENU
	public final static String SLIDER_BACKGROUND = "elementosMenu/slider_background.png";
	public final static String SLIDER_KNOB = "elementosMenu/slider_knob.png";
	public final static String FLECHA_ATRAS = "elementosMenu/flecha_atras.png";
	public final static String FLECHA_PERSONAJES = "elementosMenu/flecha_personajes.png";
	public final static String PERSONAJE_JOSE = "elementosMenu/Personaje_Samurai.png";
	public final static String CONTORNO_PERSONAJE_ELECCION = "elementosMenu/contorno_eleccion.png";
	// ELEMENTOS HUD
	public final static String ICONO_VIDA_NINJA = "elementosHUD/ninjasLife.png";

	// ELEMENTOS INVENTARIO
	public final static String POCION_VIDA = "elementosInventario/pocionVida.png";
	public final static String VELOCIDAD = "elementosInventario/velocidad.png";
	public final static String ATAQUE = "elementosInventario/mayorAtaque.png";
	public final static String CAJA_HERRAMIENTAS = "elementosInventario/cajaHerramientas.png";
}
