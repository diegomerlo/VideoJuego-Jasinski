package com.slaythemall.elementos_inventario;

public enum TiposElemento {
	VELOCIDAD, ATAQUE,VIDA;
}
