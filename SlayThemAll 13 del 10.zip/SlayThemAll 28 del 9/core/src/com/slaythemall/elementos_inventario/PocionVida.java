package com.slaythemall.elementos_inventario;

import com.slaythemall.objetos.Jugador;

public class PocionVida extends Elemento {

	public PocionVida(Jugador jugador) {
		super("Pocion de Vida", 2, TiposElemento.VIDA, jugador);
	}

}
