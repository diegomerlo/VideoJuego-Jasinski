<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="castlevania" tilewidth="2039" tileheight="375" tilecount="1" columns="1">
 <image source="castlevania.png" width="2039" height="375"/>
</tileset>
