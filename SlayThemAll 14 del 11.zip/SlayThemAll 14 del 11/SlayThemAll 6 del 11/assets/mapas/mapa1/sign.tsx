<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="sign" tilewidth="22" tileheight="31" tilecount="1" columns="1">
 <image source="sign.png" width="22" height="31"/>
</tileset>
