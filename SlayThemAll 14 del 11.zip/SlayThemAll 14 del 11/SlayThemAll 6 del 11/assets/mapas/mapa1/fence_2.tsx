<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="fence_2" tilewidth="72" tileheight="19" tilecount="1" columns="1">
 <image source="fence_2.png" width="72" height="19"/>
</tileset>
