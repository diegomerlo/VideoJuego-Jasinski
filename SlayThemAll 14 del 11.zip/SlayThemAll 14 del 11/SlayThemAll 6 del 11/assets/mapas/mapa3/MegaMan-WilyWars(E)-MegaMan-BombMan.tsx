<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="MegaMan-WilyWars(E)-MegaMan-BombMan" tilewidth="16" tileheight="16" tilecount="20400" columns="272">
 <image source="MegaMan-WilyWars(E)-MegaMan-BombMan.png" width="4352" height="1200"/>
</tileset>
