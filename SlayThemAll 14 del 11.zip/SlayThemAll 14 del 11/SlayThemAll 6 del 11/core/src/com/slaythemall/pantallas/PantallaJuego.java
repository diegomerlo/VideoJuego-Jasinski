package com.slaythemall.pantallas;

import static com.slaythemall.utiles.Constantes.PPM;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.graphics.g3d.particles.ParticleShader.Inputs;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.Drawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.slaythemall.animaciones.AnimacionNPC;
import com.slaythemall.colisiones.ContactListenerImpl;
import com.slaythemall.elementos_inventario.Elemento;
import com.slaythemall.elementos_inventario.PocionVida;
import com.slaythemall.elementos_inventario.Velocidad;
import com.slaythemall.elementos_inventario.Ataque;
import com.slaythemall.escenas.HUD;
import com.slaythemall.mapas.GestorMapas;
import com.slaythemall.mapas.TiledMaps;
import com.slaythemall.objetos.Enemigo;
import com.slaythemall.objetos.Jugador;
import com.slaythemall.utiles.Config;
import com.slaythemall.utiles.Recursos;
import com.slaythemall.utiles.Render;
import com.slaythemall.mapas.GestorMapas;

public class PantallaJuego extends ScreenAdapter {

	private OrthographicCamera camara;
	private Viewport viewport;
	private SpriteBatch batch;
	private World mundo;
	private Box2DDebugRenderer box2DDebugRenderer;
	private OrthogonalTiledMapRenderer orthogonalTiledMapRenderer;
	private GestorMapas gestorMapas;
	private TiledMaps tiledMaps;
	private Jugador jugador;
	private Enemigo[] enemigos;
	private HUD hud;
	private ImageButton backButton;
	private boolean juegoPausado = false;
	private PantallaPausa pantallaPausa;
	private boolean finJuego = false;
	private Vector2 posicionInicial;
	private Stage stage;
	private ImageButton pocionVidaBoton, velocidadBoton, ataqueBoton;
	private ImageButton[] itemButtons;
	private int selectedIndex = 0;
	private Label[] itemLabels; // Etiquetas para mostrar la cantidad de usos
	private Elemento elementos[];
	private AnimacionNPC animacionNPC;
	private int proximoMapa= 2;
	

	public PantallaJuego() {
		// Configura la cámara y el viewport
		this.camara = new OrthographicCamera();
		this.viewport = new FitViewport(Config.ANCHO, Config.ALTO, camara);
		this.camara.setToOrtho(false, Config.ANCHO, Config.ALTO);
		this.batch = new SpriteBatch();
		this.mundo = new World(new Vector2(0, -25f), false);
		
		this.animacionNPC = new AnimacionNPC("IDLE", 6, 0.1f);
		
		this.box2DDebugRenderer = new Box2DDebugRenderer();
		this.gestorMapas = new GestorMapas();
		this.tiledMaps = new TiledMaps(this);

		TiledMap mapa = gestorMapas.cargarMapa("mapas/mapa1/mapa.tmx");
		this.orthogonalTiledMapRenderer = new OrthogonalTiledMapRenderer(mapa);
		this.tiledMaps.iniciarMapa(mapa);
		mundo.setContactListener(new ContactListenerImpl());
		this.hud = new HUD(this.batch);

		this.stage = new Stage(new ScreenViewport(), batch);
		this.elementos = new Elemento[] { new PocionVida(jugador), new Velocidad(jugador), new Ataque(jugador) };

		configurarInventario();
	}

	private void configurarInventario() {
		Table table = new Table();
		table.center(); // Configuracion de posicion de la barra de herramientas
		table.bottom();
		table.setFillParent(true);

		pocionVidaBoton = createButton(Recursos.POCION_VIDA);
		velocidadBoton = createButton(Recursos.VELOCIDAD);
		ataqueBoton = createButton(Recursos.ATAQUE);

		itemButtons = new ImageButton[] { pocionVidaBoton, velocidadBoton, ataqueBoton };
		itemLabels = new Label[itemButtons.length];

		BitmapFont font = new BitmapFont(); // Puedes personalizar esta fuente
		LabelStyle labelStyle = new LabelStyle(font, Color.BLACK);

		for (int i = 0; i < itemButtons.length; i++) {
			Table itemTable = new Table();

			// Crear y configurar la etiqueta
			itemLabels[i] = new Label(String.valueOf(elementos[i].getCantUsos()), labelStyle);
			itemLabels[i].setFontScale(1.5f); // Ajustar el tamaño de la fuente
			itemTable.add(itemButtons[i]).size(60, 60).pad(2).row();
			itemTable.add(itemLabels[i]).padTop(-50); // Ajusta el padding para superponer la etiqueta
			table.add(itemTable).pad(10); // Agrega el conjunto de botón y etiqueta a la tabla principal
		}

		stage.addActor(table);

		for (int i = 0; i < itemButtons.length; i++) {
			updateSelection(this.selectedIndex);
			if (this.selectedIndex != (itemButtons.length - 1))
				this.selectedIndex++;
			else
				this.selectedIndex = 0;
		}
	}

	private ImageButton createButton(String texturePath) {
		Texture texture = new Texture(Gdx.files.internal(texturePath));
		Drawable drawable = new TextureRegionDrawable(new TextureRegion(texture));
		return new ImageButton(drawable);
	}

	private void updateSelection(int selectedIndex) {
		for (int i = 0; i < itemButtons.length; i++) {
			ImageButton button = itemButtons[i];
			if (i == selectedIndex) {
				// Crear un nuevo estilo para el botón seleccionado
				ImageButton.ImageButtonStyle style = new ImageButton.ImageButtonStyle(button.getStyle());
				Texture texture = new Texture(Gdx.files.internal(Recursos.CAJA_HERRAMIENTAS));
				Drawable drawable = new TextureRegionDrawable(new TextureRegion(texture));
				style.up = drawable; // Cambia el fondo del botón seleccionado
				button.setStyle(style);
				button.setColor(Color.WHITE); // Resaltado
			} else {
				button.setColor(Color.GRAY); // No resaltado
			}
		}
	}

	private void update() {
		mundo.step(1 / 60f, 6, 2);
		camaraActualizar();
		viewport.apply(); // Aplica los cambios del viewport
		batch.setProjectionMatrix(camara.combined);
		orthogonalTiledMapRenderer.setView(camara);
		jugador.update();
		jugador.actualizarSensorEspada();

		//hudUpdate(Gdx.graphics.getDeltaTime());

		// Actualizar enemigos y eliminar los muertos
		for (int i = 0; i < enemigos.length; i++) {
			if (enemigos[i] != null) {
				enemigos[i].update();
				if (enemigos[i].getVida() <= 0) {
					enemigos[i] = null; // Eliminar el enemigo de la lista
					// finJuego = true;
				}
			}
		}
		if (Gdx.input.isKeyJustPressed(Input.Keys.E)) {
			
			// Render.app.setScreen(new PantallaMenu());
			reestablecerElementos("mapas/mapa"+proximoMapa+"/mapa.tmx");
			
			if(proximoMapa<3) {
				proximoMapa++;
			}
		
			
		}
		/*
		 * if (finJuego) { // Render.app.setScreen(new PantallaGameWin());
		 * reestablecerElementos("mapas/mapa2/mapa.tmx"); }
		 */
	}

	private void camaraActualizar() {
		Vector3 position = camara.position;
		position.x = Math.round(jugador.getBody().getPosition().x * PPM * 10) / 10f;
		position.y = (40) + Math.round(jugador.getBody().getPosition().y * PPM * 10) / 10f;
		camara.position.set(position);
		camara.update();
	}


	private void usarItem(int index) {
		if (elementos[index].getCantUsos() > 0) {
			elementos[index].restCantUsos();
			;
			itemLabels[index].setText(String.valueOf(elementos[index].getCantUsos()));
		}
	}

	@Override
	public void render(float delta) {
		
		if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
			if (juegoPausado) {
				Render.app.setScreen(this); // Volver a la pantalla del juego
			} else {
				Render.app.setScreen(new PantallaPausa(this)); // Mostrar pantalla de pausa
			}
			juegoPausado = !juegoPausado;
		}

		if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_1)) {
			selectedIndex = 0;
			usarItem(selectedIndex);
		} else if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_2)) {
			selectedIndex = 1;
			usarItem(selectedIndex);
		} else if (Gdx.input.isKeyJustPressed(Input.Keys.NUM_3)) {
			selectedIndex = 2;
			usarItem(selectedIndex);
		}

		// Llamar al método de actualización de la selección
		updateSelection(this.selectedIndex);

		if (!juegoPausado) {
			this.update(); // Solo actualiza si el juego no está pausado
		}
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		orthogonalTiledMapRenderer.render();
		batch.setProjectionMatrix(camara.combined);
		batch.begin();
		this.camara.zoom = 0.7f;//
		jugador.render(batch);
		
		TextureRegion currentFrame = animacionNPC.getFrame(null, Gdx.graphics.getDeltaTime());
		
		for (Enemigo enemigo : enemigos) {
			if (enemigo != null) {
				enemigo.update();
				enemigo.render(batch);
			}
		}
		
		batch.draw(currentFrame, 0, 0);
		batch.end();

		stage.act(delta);
		stage.draw();

		batch.setProjectionMatrix(hud.stage.getCamera().combined);
		box2DDebugRenderer.render(mundo, camara.combined.scl(PPM));
		hud.stage.draw();
	}

	@Override
	public void dispose() {
		// Dispose de cada uno de los componentes utilizados
		batch.dispose();
		stage.dispose();
		mundo.dispose();
		box2DDebugRenderer.dispose();
		orthogonalTiledMapRenderer.dispose();
		gestorMapas.dispose();
	}

	public void reestablecerElementos(String rutaMapa) {

		tiledMaps.eliminarCuerposEnemigos();
		// Cargar el nuevo mapa utilizando el gestor de mapas
		TiledMap nuevoMapa = gestorMapas.cargarMapa(rutaMapa);

		// Actualizar el renderer con el nuevo mapa
		this.orthogonalTiledMapRenderer = gestorMapas.getRenderer();

		tiledMaps.iniciarMapa(nuevoMapa); // Reconfigura los elementos como colisiones
		jugador.reiniciarPosicionInicial(posicionInicial);

		camara.update();

	}

	public void resize(int width, int height) {
		viewport.update(width, height, true);
		stage.getViewport().update(width, height, true);
	}

	public World getMundo() {
		return mundo;
	}

	public SpriteBatch getBatch() {
		return batch;
	}

	public void setJugador(Jugador jugador) {
		this.jugador = jugador;
	}

	public void setEnemigos(Enemigo[] enemigos) {
		this.enemigos = enemigos;
	}

	public void setPausado(boolean pausado) {
		this.juegoPausado = pausado;
		if (pausado) {
			mundo.setGravity(new Vector2(0, 0)); // Desactivar la gravedad
			Gdx.input.setInputProcessor(null); // Desactivar el procesador de entrada
		} else {
			mundo.setGravity(new Vector2(0, -25f)); // Restaurar la gravedad
			configurarInputProcessor(); // Volver a configurar el procesador de entrada
			jugador.resetEntradas(); // Resetear las entradas para evitar estados incorrectos
		}
	}

	private void configurarInputProcessor() {
		Gdx.input.setInputProcessor(jugador.getEntradas()); // Configurar el procesador de entradas del jugador
	}

	public Jugador getJugador() {
		return this.jugador;
	}
	
	  public void setPosicionInicial(Vector2 posicion) {
	        this.posicionInicial = posicion;
	    }

}
