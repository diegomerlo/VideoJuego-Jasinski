package com.slaythemall.pantallas;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.ScreenViewport;
import com.slaythemall.elementos.Texto;
import com.slaythemall.utiles.Recursos;
import com.slaythemall.utiles.Render;

public class PantallaPausa extends ScreenAdapter {
    private Stage stage;
    private SpriteBatch batch;
    private PantallaJuego pantallaJuego;
    private Texto[] textos = new Texto[2];
    private int seleccion = 0;
    private Texture fondoPausa;

    public PantallaPausa(PantallaJuego pantallaJuego) {
        this.pantallaJuego = pantallaJuego;
        this.batch = pantallaJuego.getBatch();
        this.stage = new Stage(new ScreenViewport(), batch);

        fondoPausa = new Texture(Gdx.files.internal(Recursos.FONDO_MENU));

        textos[0] = new Texto(Recursos.FUENTE_MENU, 30, Color.WHITE, false);
        textos[0].setTexto("Continuar");
        textos[0].setPosicion((Gdx.graphics.getWidth() / 2)-100, Gdx.graphics.getHeight() / 2);

        textos[1] = new Texto(Recursos.FUENTE_MENU, 30, Color.WHITE, false);
        textos[1].setTexto("Salir");
        textos[1].setPosicion((Gdx.graphics.getWidth() / 2) - 100, (Gdx.graphics.getHeight() / 2)-100);

        Gdx.input.setInputProcessor(new com.badlogic.gdx.InputAdapter() {
            @Override
            public boolean keyDown(int keycode) {
                if (keycode == Input.Keys.UP) {
                    seleccion = (seleccion - 1 + 2) % 2;
                    actualizarTexto();
                } else if (keycode == Input.Keys.DOWN) {
                    seleccion = (seleccion + 1) % 2;
                    actualizarTexto();
                } else if (keycode == Input.Keys.ENTER) {
                    if (seleccion == 0) {
                        // Reanudar el juego
                        pantallaJuego.setPausado(false);
                        renderSceen(pantallaJuego);
                    } else if (seleccion == 1) {
                        renderSceen(new PantallaMenu());
                    }
                } else if (keycode == Input.Keys.ESCAPE) {                	
                	renderSceen(new PantallaMenu());
                }
                return false;
            }
        });
    }

    private void renderSceen(Screen screen) {
    	Render.app.setScreen(screen);
    }
    
    private void actualizarTexto() { //IF TERNARIO PARA LOS COLORES
        textos[0].setColor(seleccion == 0 ? Color.RED : Color.WHITE);
        textos[1].setColor(seleccion == 1 ? Color.RED : Color.WHITE);
    }

    public void render(float delta) {
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        Render.batch.begin();
        Render.batch.draw(fondoPausa, 0, 0, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        	textos[0].dibujar();
        	textos[1].dibujar();
       	Render.batch.end();

        stage.act(Gdx.graphics.getDeltaTime());
        stage.draw();
    }


    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);
    }

    @Override
    public void dispose() {
        stage.dispose();
        fondoPausa.dispose(); // Limpiar los recursos de la textura
    }
}
