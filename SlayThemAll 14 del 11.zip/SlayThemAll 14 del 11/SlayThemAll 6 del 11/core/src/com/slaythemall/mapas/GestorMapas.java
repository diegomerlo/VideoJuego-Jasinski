package com.slaythemall.mapas;

import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;

public class GestorMapas {

    private TiledMap mapaActual;
    private OrthogonalTiledMapRenderer renderer;
    private TmxMapLoader mapLoader;

    public GestorMapas() {
        this.mapLoader = new TmxMapLoader();
    }

    public TiledMap cargarMapa(String rutaMapa) {
        // Deshacerse del mapa y renderer actuales si existen
        if (mapaActual != null) {
            mapaActual.dispose();
        }
        if (renderer != null) {
            renderer.dispose();
        }

        // Cargar el nuevo mapa
        this.mapaActual = mapLoader.load(rutaMapa);

        // Crear un nuevo renderer para el nuevo mapa
        this.renderer = new OrthogonalTiledMapRenderer(mapaActual);

        return mapaActual;
    }

    public OrthogonalTiledMapRenderer getRenderer() {
        return renderer;
    }

    public void dispose() {
        if (mapaActual != null) {
            mapaActual.dispose();
        }
        if (renderer != null) {
            renderer.dispose();
        }
    }
}