package com.slaythemall.game;

import com.badlogic.gdx.Game;
//import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.slaythemall.musicas.Musica;
import com.slaythemall.musicas.MusicaAmbiente;
import com.slaythemall.pantallas.PantallaInventario;
import com.slaythemall.utiles.Render;

public class SlayThemAll extends Game {
	Musica musica;
	public static SlayThemAll INSTANCE;

	public SlayThemAll() {
		INSTANCE = this;
	}

	@Override
	public void create() {
		Render.app = this;
		Render.batch = new SpriteBatch();
//        this.setScreen(new PantallaInicio());
		this.setScreen(new PantallaInventario());
//		MusicaAmbiente.AMBIENTE_PRINCIPAL.playMusic();
//		MusicaAmbiente.AMBIENTE_PRINCIPAL.loopingMusic();
	}

	@Override
	public void render() {
		super.render();
	}

	@Override
	public void dispose() {
		Render.batch.dispose();
		System.exit(-1);
	}
}
