package com.slaythemall.objetos;

import com.badlogic.gdx.Gdx;

public class EstadoEnemigo {
    private Estados estadoActual;
    private Estados estadoAnterior;
    private boolean recibiendoGolpe; 
    private boolean atacando; // Nuevo estado para controlar si está atacando
    private float timerAtaque; // Timer para controlar la duración del sensor de ataque temporal
    private final float DURACION_SENSOR_ATAQUE = 0.5f; // Duración del sensor de ataque en segundos
    private float tiempoRecibiendoGolpe;
    private final float DURACION_RECIBIR_GOLPE = 0.5f;
    
    public EstadoEnemigo() {
        estadoActual = Estados.IDLE;
        estadoAnterior = Estados.IDLE;
        recibiendoGolpe = false;
        atacando = false;
        timerAtaque = 0;
        tiempoRecibiendoGolpe = 0;
    }

    public void actualizarEstado(Enemigo enemigo, float delta) {
        boolean isCaminando = enemigo.isCaminando();
        boolean isAtacando = enemigo.isAtacando();

        // Revisar si está recibiendo golpe antes que cualquier otra cosa
        if (recibiendoGolpe) {
            actualizarEstadoRecibiendoGolpe(enemigo, delta);
            atacando = false; // Cancela el ataque si está recibiendo daño
        } else if (isAtacando) {
            estadoActual = Estados.ATACAR;
            if (!atacando) { 
                iniciarSensorAtaque(enemigo);
            }
            atacando = true;
        } else if (isCaminando) {
            estadoActual = Estados.CAMINAR;
        } else {
            estadoActual = Estados.IDLE;
        }

        // Manejar desactivación del sensor de ataque al terminar
        if (atacando) {
            timerAtaque -= delta;
            if (enemigo.animacionEnemigo.isAttackAnimationFinished() || timerAtaque <= 0) {
                desactivarSensorAtaque(enemigo);
                atacando = false;
            }
        }

        if (estadoActual != estadoAnterior) {
            enemigo.resetStateTime();
        }

        estadoAnterior = estadoActual;
    }

    private void iniciarSensorAtaque(Enemigo enemigo) {
        enemigo.activarSensorAtaque();
        timerAtaque = DURACION_SENSOR_ATAQUE; // Inicia el temporizador del sensor
    }

    private void desactivarSensorAtaque(Enemigo enemigo) {
        enemigo.desactivarSensorAtaque();
    }

    private void actualizarEstadoRecibiendoGolpe(Enemigo enemigo, float delta) {
        estadoActual = Estados.RECIBIR_GOLPE;
        tiempoRecibiendoGolpe += delta;
        if (enemigo.animacionEnemigo.isRecibirGolpeAnimationFinished() || tiempoRecibiendoGolpe >= DURACION_RECIBIR_GOLPE) {
            recibiendoGolpe = false;
            tiempoRecibiendoGolpe = 0;
            estadoActual = Estados.IDLE;
        }
    }

    public Estados getEstadoActual() {
        return estadoActual;
    }

    public void setRecibiendoGolpe(boolean valor) {
        recibiendoGolpe = valor; 
    }
}
