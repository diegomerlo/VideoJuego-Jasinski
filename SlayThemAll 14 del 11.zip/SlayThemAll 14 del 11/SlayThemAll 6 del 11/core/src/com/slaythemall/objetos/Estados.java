package com.slaythemall.objetos;

public enum Estados {
	CAMINAR, SALTAR, CAER, IDLE, DASH, RECIBIR_GOLPE, ATACAR, CAYENDO;
}
