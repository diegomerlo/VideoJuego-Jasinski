package com.slaythemall.objetos;

import com.badlogic.gdx.physics.box2d.Body;
import com.slaythemall.animaciones.AnimacionConfig;
import com.slaythemall.objetos.Estados;
import com.slaythemall.utiles.Recursos;

import java.util.HashMap;
import java.util.Map;

public class TrainingDummy extends Enemigo {

    private static final int VIDA_INICIAL = 60;
    public static final String ATLAS_PATH = Recursos.ANIMACIONES_TRAININGDUMMY;
    public static final float DAÑO= 15;
    
    
    public TrainingDummy(float ancho, float alto, Body body,Jugador jugador) {
        super(ancho, alto, body, ATLAS_PATH, VIDA_INICIAL,getAnimacionConfig(),jugador,DAÑO);
    }

    private static Map<Estados, AnimacionConfig> getAnimacionConfig() {
        Map<Estados, AnimacionConfig> config = new HashMap<>();
        config.put(Estados.IDLE, new AnimacionConfig("idle", 4, 0.2f));
        config.put(Estados.RECIBIR_GOLPE, new AnimacionConfig("recibegolpe", 5, 0.1f));
        config.put(Estados.ATACAR, new AnimacionConfig("recibegolpe",5,0.3f));
        config.put(Estados.CAMINAR, new AnimacionConfig("recibegolpe",5,0.3f));
        return config;
    }
}
