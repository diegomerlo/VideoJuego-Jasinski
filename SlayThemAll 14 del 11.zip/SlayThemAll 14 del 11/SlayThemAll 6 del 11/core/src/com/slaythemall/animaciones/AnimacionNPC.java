package com.slaythemall.animaciones;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.slaythemall.objetos.Estados;
import com.slaythemall.utiles.Recursos;

public class AnimacionNPC extends Animacion {

    private Animation<TextureRegion> animacion;

    public AnimacionNPC(String regionName, int numFrames, float frameDuration) {
        super(new TextureAtlas(Gdx.files.internal(Recursos.ANIMACIONES_NPC)));
        animacion = createAnimation(regionName, numFrames, frameDuration);
    }

    @Override
    public TextureRegion getFrame(Estados estadoActual, float deltaTime) {
        stateTime += deltaTime;
        return animacion.getKeyFrame(stateTime, true);  // Siempre reproduce en loop
    }

    public void resetStateTime() {
        stateTime = 0f;  // Reinicia el tiempo de la animación
    }

}
