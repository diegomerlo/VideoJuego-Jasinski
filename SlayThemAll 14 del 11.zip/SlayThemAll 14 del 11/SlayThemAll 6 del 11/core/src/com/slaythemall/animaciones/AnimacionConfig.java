package com.slaythemall.animaciones;

public class AnimacionConfig {
    private String regionName;
    private int numFrames;
    private float frameDuration;

    public AnimacionConfig(String regionName, int numFrames, float frameDuration) {
        this.regionName = regionName;
        this.numFrames = numFrames;
        this.frameDuration = frameDuration;
    }

    public String getRegionName() {
        return regionName;
    }

    public int getNumFrames() {
        return numFrames;
    }

    public float getFrameDuration() {
        return frameDuration;
    }
}

