package com.slaythemall.escenas;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator.FreeTypeFontParameter;
import com.slaythemall.pantallas.TiposElementosInventario;
import com.slaythemall.utiles.Config;
import com.slaythemall.utiles.Recursos;

public class HUD {
    private int vidasNinjaVisibles = 10;
    public Stage stage;
    private Viewport viewport;
    private int puntajeActual;
    private Label puntajeLabel;
    private Label nivelLabel;
    private Image[] vidasNinja;
    private static TiposElementosInventario elementoInventario;

    // Textura para las estrellas y para el icono de puntaje
    private Texture textureEstrella;
    private Texture textureIconoPuntaje;  // Nueva textura para el icono al lado del puntaje

    public HUD(SpriteBatch b) {
        this.puntajeActual = 0;
        this.viewport = new FitViewport(Config.ANCHO, Config.ALTO, new OrthographicCamera());
        this.stage = new Stage(viewport, b);

        // Crear una tabla para organizar los elementos del HUD
        Table table = new Table();
        table.top();
        table.setFillParent(true);

        // Cargar fuentes personalizadas desde un archivo .ttf
        FreeTypeFontGenerator generador = new FreeTypeFontGenerator(Gdx.files.internal(Recursos.FUENTE_MENU));
        FreeTypeFontParameter parametros = new FreeTypeFontParameter();
        parametros.size = 24;  // Ajusta el tamaño de la fuente según sea necesario
        parametros.color = Color.WHITE;

        BitmapFont fuentePersonalizada = generador.generateFont(parametros);
        Label.LabelStyle estiloLabel = new Label.LabelStyle(fuentePersonalizada, Color.WHITE);

        // Crear texturas (íconos) para las estrellas y el icono del puntaje
        textureEstrella = new Texture(Gdx.files.internal(Recursos.ICONO_VIDA_NINJA));
        textureIconoPuntaje = new Texture(Gdx.files.internal(elementoInventario.getDireccionImagen()));  // Icono para el puntaje

        // Inicializar el arreglo de imágenes para las vidasNinja
        int numerovidasNinja = 10;
        vidasNinja = new Image[numerovidasNinja];
        for (int i = 0; i < numerovidasNinja; i++) {
            vidasNinja[i] = new Image(textureEstrella);
            table.add(vidasNinja[i]).size(32, 32).padTop(0).left();  // Vidas en la misma fila
        }

        // Añadir la imagen del icono del puntaje al lado izquierdo
        Image iconoPuntaje = new Image(textureIconoPuntaje);
        table.add(iconoPuntaje).size(32, 32).padLeft(10); // Icono del puntaje a la izquierda

        this.puntajeLabel = new Label(String.format("%06d", this.puntajeActual), estiloLabel);
        table.add(puntajeLabel).padLeft(10); // Puntaje a la derecha del icono

        // Nivel
        this.nivelLabel = new Label("NIVEL 1", estiloLabel);

        // No es necesario usar table.row() aquí ya que queremos todo en una sola fila
        // Añadir el nivel y puntaje a la misma fila
        table.add(nivelLabel).expandX().center(); // NIVEL 1 centrado
        table.add(puntajeLabel).padTop(10).right(); // Puntuación a la derecha

        stage.addActor(table);

        generador.dispose();
    }

    // Método para sumar puntaje
    public void sumarPuntaje(int puntos) {
        puntajeActual += puntos;
        puntajeLabel.setText(String.format("%d", puntajeActual));
    }

    // Método para recibir un golpe
    public void recibirGolpe() {
        if (vidasNinjaVisibles > 0) {
            vidasNinjaVisibles--; // Reduce el número de vidas visibles
            actualizarvidasNinja(); // Actualiza las vidas inmediatamente
        }
    }

    // Método para actualizar la visibilidad de las vidas
    private void actualizarvidasNinja() {
        for (int i = 0; i < vidasNinja.length; i++) {
            if (i < vidasNinjaVisibles) {
                vidasNinja[i].setVisible(true);  // Muestra las vidas visibles
            } else {
                vidasNinja[i].setVisible(false); // Oculta las vidas no visibles
            }
        }
    }

    public static void setElementoInventario(TiposElementosInventario elementoInventario) {
        HUD.elementoInventario = elementoInventario;
    }

    // Método para liberar recursos
    public void dispose() {
        textureEstrella.dispose();  // Libera la textura de las estrellas
        textureIconoPuntaje.dispose(); // Libera la textura del icono de puntaje
        stage.dispose();  // Libera el stage
    }
}
