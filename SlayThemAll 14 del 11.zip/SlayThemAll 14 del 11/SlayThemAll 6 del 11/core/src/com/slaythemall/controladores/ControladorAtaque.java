package com.slaythemall.controladores;

import static com.slaythemall.utiles.Constantes.PPM;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.slaythemall.musicas.EfectoSonido;
import com.slaythemall.objetos.Enemigo;
import com.slaythemall.objetos.Jugador;

public class ControladorAtaque {
    private Jugador jugador;
    private boolean isAttacking;
    private int attackCount;
    private float attackCooldown;
    private final float attackCooldownDuration = 0.5f; // Duración del cooldown en segundos
    private float attackBufferTime;
    private final float attackBufferDuration = 0.5f; // Tiempo permitido para el buffer de ataque
    private float attackTime; // Tiempo que ha pasado desde que comenzó el ataque
    private float attackDuration;
    private float comboResetTime; // Tiempo para resetear el combo si no se realiza el siguiente ataque
    private float timeSinceLastAttack; // Tiempo desde el último ataque
    private Enemigo enemyContact;
    private float timeSinceLastHit;
    private final float hitInterval = 0.6f; // Intervalo de tiempo permitido entre golpes
    private Fixture sensorEspada;
    private float espadaAncho;
    private float espadaAlto;
    
    // Definir el tiempo en la animación donde se registra el golpe 
    private final float golpeEnAnimacion = 0.4f;

    public ControladorAtaque(Jugador jugador) {
        this.jugador = jugador;
        this.isAttacking = false;
        this.attackCount = 0;
        this.attackCooldown = 0;
        this.attackBufferTime = 0;
        this.attackDuration = 0.6f;
        this.attackTime = 0f;
        this.comboResetTime = 0.4f;
        this.timeSinceLastAttack = 0f;
        this.timeSinceLastHit = 0f;
    }

    public void update() {
        float deltaTime = Gdx.graphics.getDeltaTime();

        if (timeSinceLastHit > 0) {
            timeSinceLastHit -= deltaTime;
        }

        if (attackCooldown > 0) {
            attackCooldown -= deltaTime;
        }

        if (attackBufferTime > 0) {
            attackBufferTime -= deltaTime;
        }

        if (isAttacking) {
            attackTime += deltaTime;
            timeSinceLastAttack = 0f;

            // Solo registrar el golpe en el momento adecuado
            if (attackTime >= golpeEnAnimacion && attackTime < golpeEnAnimacion + deltaTime && enemyContact != null) {
                enemyContact.recibirGolpe(jugador.getDaño());
                timeSinceLastHit = hitInterval; // Reiniciar el tiempo desde el último golpe
                
                // Empujar al enemigo
                Vector2 direccionEmpuje = new Vector2(jugador.isFacingRight() ? 1 : -1, 0);
                enemyContact.getBody().applyLinearImpulse(direccionEmpuje.scl(2f), enemyContact.getBody().getWorldCenter(), true);
                
            }

            // Terminar la animación de ataque
            if (attackTime >= attackDuration) {
                isAttacking = false;
                attackTime = 0f;

                if (attackCount >= 3) {
                    attackCooldown = attackCooldownDuration;
                    attackCount = 0;
                }
            }
        } else {
            timeSinceLastAttack += deltaTime;

            if (timeSinceLastAttack >= comboResetTime) {
                attackCount = 0;
            }
        }

        if (isAttacking) {
            EfectoSonido.EFECTO_ESPADA_BASICO.playMusic();
        }
    }

    public void attack() {
        isAttacking = true;
        attackCount++;
        attackBufferTime = attackBufferDuration; // Iniciar el buffer de tiempo para permitir ataques rápidos
        attackTime = 0f; // Reiniciar el tiempo del ataque
        timeSinceLastAttack = 0f; // Resetear el tiempo desde el último ataque
    }

    public boolean isAttacking() {
        return isAttacking;
    }

    public boolean canAttack() {
        return attackCooldown <= 0 && !isAttacking;
    }

    public void setEnemyContact(Enemigo enemigo) {
        this.enemyContact = enemigo;
    }

    public void setSensorEspada(Fixture sensorEspada) {
        this.sensorEspada = sensorEspada;
    }

    public void setEspadaDimensiones(float ancho, float alto) {
        this.espadaAncho = ancho;
        this.espadaAlto = alto;
    }

    public void actualizarSensorEspada(boolean isFacingRight) {
        if (sensorEspada != null) {
            PolygonShape shape = (PolygonShape) sensorEspada.getShape();
            float width = espadaAncho / 2 / PPM;
            float height = espadaAlto / 2 / PPM;

            float offsetX = isFacingRight ? width : -width;
            float offsetY = height;

            Vector2[] vertices = {
                new Vector2(-width + offsetX, -height + offsetY),
                new Vector2(width + offsetX, -height + offsetY),
                new Vector2(width + offsetX, height + offsetY),
                new Vector2(-width + offsetX, height + offsetY)
            };

            shape.set(vertices);
        }
    }
    }

