package com.slaythemall.objetos;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import static com.slaythemall.utiles.Constantes.PPM;

public class Jugador extends GameEntity {

	private int contadorSalto;
	
	public Jugador(float ancho, float alto, Body body) {
		super(ancho, alto, body);
		this.velocidad = 10f;
		this.contadorSalto=0;
	}

	@Override
	public void update() {
		x = body.getPosition().x * PPM;
		y = body.getPosition().y * PPM;
		
		verificarEntradaDeUsuario();
	}

	@Override
	public void render(SpriteBatch batch) {

	}
	
	private void verificarEntradaDeUsuario() {

		velX = 0;
		if (Gdx.input.isKeyPressed(Input.Keys.D)) {
			velX = 1;

		}

		if (Gdx.input.isKeyPressed(Input.Keys.A)) {
			velX = -1;

		}

		if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE) && contadorSalto < 2) {
			float fuerza = body.getMass() * 18;
			body.setLinearVelocity(body.getLinearVelocity());
			body.applyLinearImpulse(new Vector2(0, fuerza), body.getPosition(), true);
			contadorSalto++;
		}

		// reset contador de salto
		
		if (body.getLinearVelocity().y == 0) {
			contadorSalto=0;
		}

		body.setLinearVelocity(velX * velocidad, body.getLinearVelocity().y<25? body.getLinearVelocity().y: 25);

	}

}
