package com.slaythemall.musica;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;

public class Musica{

	private Music backgroundMusic;
	
	public Musica(String rutaCancion){
		backgroundMusic = Gdx.audio.newMusic(Gdx.files.internal(rutaCancion));
        // Configurar la música para que se repita
        backgroundMusic.setLooping(true);
        // Establecer el volumen (0.0 a 1.0)
        backgroundMusic.setVolume(0.1f);
        // Reproducir la música
        backgroundMusic.play();
	}

	public void stopMusic() {
		backgroundMusic.stop();
	}
	
	public void dispose() {
		if (backgroundMusic != null) {
            backgroundMusic.dispose();
        }
	}
}
