package com.slaythemall.game;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.slaythemall.musica.Musica;
import com.slaythemall.pantallas.PantallaInicio;
import com.slaythemall.pantallas.PantallaJuego;
import com.slaythemall.pantallas.PantallaMenu;
import com.slaythemall.utiles.Recursos;
import com.slaythemall.utiles.Render;

public class SlayThemAll extends Game {
	
	Musica musica;
	public static SlayThemAll INSTANCE;
	private int anchoPantalla, altoPantalla;
	private OrthographicCamera camara;
	
	public SlayThemAll() {
		INSTANCE = this;
	}
	
	@Override
	public void create () {
		Render.app = this;
		Render.batch = new SpriteBatch();
		this.setScreen(new PantallaInicio());
		//this.setScreen(new PantallaMenu());
		//this.setScreen(new PantallaJuego());
		
		musica = new Musica(Recursos.MUSICA_FONDO_NIVEL_1);
	}

	@Override
	public void render () {
		super.render();
	}
	
	@Override
	public void dispose () {
		Render.batch.dispose();
		musica.dispose();
	}
}
