package com.slaythemall.utiles;

public class Recursos {
	
	//FONDOS
	public final static String PRUEBA_IMAGEN = "fondos/desarrolladores.png";
	public final static String FONDO_MENU = "fondos/fondoMenuInicio.png";
	
	//FUENTES
	public final static String FUENTE_MENU = "fuentes/Crang.ttf";
	
	//MUSICAS
	public final static String MUSICA_FONDO_NIVEL_1 = "musica/electroMusic.mp3";
	
}
