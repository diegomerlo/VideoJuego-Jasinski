package com.slaythemall.utiles;

public class Recursos {
	
	public final static String PRUEBA_IMAGEN = "fondos/desarrolladores.png";
	public final static String FONDO_MENU = "fondos/fondoMenuInicio.png";
	public final static String FUENTE_MENU = "fuentes/Crang.ttf";
	
}
