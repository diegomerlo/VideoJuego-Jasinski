package com.slaythemall.pantallas;

import static com.slaythemall.utiles.Constantes.PPM;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.World;
import com.slaythemall.objetos.Jugador;
import com.slaythemall.utiles.TiledMaps;
import com.slaythemall.utiles.Config;


public class PantallaJuego extends ScreenAdapter {

	private OrthographicCamera camara;
	private SpriteBatch batch;
	private World mundo;
	private Box2DDebugRenderer box2DDebugRenderer;

	private OrthogonalTiledMapRenderer orthogonalTiledMapRenderer;
	private TiledMaps tiledMaps;

	// game objects
	private Jugador jugador;

	public PantallaJuego() {
		
		this.camara = new OrthographicCamera();
		this.camara.setToOrtho(false, Config.ANCHO, Config.ALTO);
		
		this.camara = camara;
		this.batch = new SpriteBatch();
		this.mundo = new World(new Vector2(0, -25f), false);
		this.box2DDebugRenderer = new Box2DDebugRenderer();

		this.tiledMaps = new TiledMaps(this);
		this.orthogonalTiledMapRenderer = tiledMaps.iniciarMapa();

	}

	private void update() {
		mundo.step(1 / 60f, 6, 2);
		camaraActualizar();

		batch.setProjectionMatrix(camara.combined);
		orthogonalTiledMapRenderer.setView(camara);
		jugador.update();

		if (Gdx.input.isKeyJustPressed(Input.Keys.ESCAPE)) {
			Gdx.app.exit();

		}

	}

	private void camaraActualizar() {
		Vector3 position = camara.position;
		position.x = Math.round(jugador.getBody().getPosition().x * PPM * 10) / 10f;
		position.y = Math.round(jugador.getBody().getPosition().y * PPM * 10) / 10f;
		camara.position.set(position);

		camara.update();

	}

	@Override
	public void render(float delta) {
		this.update();

		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		orthogonalTiledMapRenderer.render();

		batch.begin();

		// render objects

		batch.end();
		box2DDebugRenderer.render(mundo, camara.combined.scl(PPM));
		// pixels per meter
	}

	public World getMundo() {
		return mundo;
	}

	public void setJugador(Jugador jugador) {
		this.jugador = jugador;

	}

}

