package com.slaythemall.musicas;

import com.slaythemall.utiles.Recursos;

public abstract class MusicaAmbiente {

	public static final Musica AMBIENTE_PRINCIPAL = new Musica(Recursos.MUSICA_FONDO_NIVEL_1);

	public static void dispose() {
		AMBIENTE_PRINCIPAL.dispose();
	}
}
