package com.slaythemall.animaciones;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.slaythemall.objetos.Estados;

public abstract class Animacion {
	protected TextureAtlas atlas;
	protected float stateTime;

	public Animacion(TextureAtlas atlas) {
		this.atlas = atlas;
		this.stateTime = 0f;
	}

	protected Animation<TextureRegion> createAnimation(String regionName, int numFrames, float frameDuration) {
		TextureRegion[] frames = new TextureRegion[numFrames];
		for (int i = 0; i < numFrames; i++) {
			frames[i] = atlas.findRegion(regionName, i + 1);
		}
		return new Animation<>(frameDuration, frames);
	}

	public abstract TextureRegion getFrame(Estados estadoActual, float deltaTime);

	public void dispose() {
		if (atlas != null) {
			atlas.dispose();
		}
	}
}
