package com.slaythemall.animaciones;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.slaythemall.objetos.Estados;

public class AnimacionEnemigo extends Animacion {
	private Animation<TextureRegion> idleAnimacion;
	private Animation<TextureRegion> recibirGolpeAnimacion;

	public AnimacionEnemigo(TextureAtlas atlas) {
		super(atlas);
		idleAnimacion = createAnimation("idle", 4, 0.2f);
		recibirGolpeAnimacion = createAnimation("recibegolpe", 5, 0.1f);
	}

	@Override
	public TextureRegion getFrame(Estados estadoActual, float deltaTime) {
		stateTime += deltaTime;
		switch (estadoActual) {
		case RECIBIR_GOLPE:
			return recibirGolpeAnimacion.getKeyFrame(stateTime, true);
		case IDLE:
		default:
			return idleAnimacion.getKeyFrame(stateTime, true);
		}
	}

	public boolean isRecibirGolpeAnimationFinished() {
		return recibirGolpeAnimacion.isAnimationFinished(stateTime);
	}

	public void resetStateTime() {
		stateTime = 0f;
	}
}
