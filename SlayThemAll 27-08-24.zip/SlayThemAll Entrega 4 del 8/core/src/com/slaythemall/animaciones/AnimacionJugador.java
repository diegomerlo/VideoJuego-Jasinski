package com.slaythemall.animaciones;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.slaythemall.objetos.Estados;

public class AnimacionJugador extends Animacion {
	private Animation<TextureRegion> caminaAnimacion;
	private Animation<TextureRegion> saltaAnimacion;
	private Animation<TextureRegion> caidaAnimacion;
	private Animation<TextureRegion> caidaRepeatAnimacion;
	private Animation<TextureRegion> idleAnimacion;
	private Animation<TextureRegion> dashAnimacion;
	private Animation<TextureRegion> atacarAnimacion;

	public AnimacionJugador(TextureAtlas atlas) {
		super(atlas);
		caminaAnimacion = createAnimation("caminar", 6, 0.1f);
		saltaAnimacion = createAnimation("salto", 3, 0.1f);
		caidaAnimacion = createAnimation("caida", 3, 0.1f);
		caidaRepeatAnimacion = createAnimation("caida_repeticion", 2, 0.1f);
		idleAnimacion = createAnimation("idle", 6, 0.1f);
		dashAnimacion = createAnimation("dash", 5, 0.08f);
		atacarAnimacion = createAnimation("atacarA", 6, 0.1f);
	}

	@Override
	public TextureRegion getFrame(Estados estadoActual, float deltaTime) {
		stateTime += deltaTime;
		switch (estadoActual) {
		case SALTAR:
			return saltaAnimacion.getKeyFrame(stateTime, true);
		case CAER:
			TextureRegion currentFrame = caidaAnimacion.getKeyFrame(stateTime, false);
			if (caidaAnimacion.isAnimationFinished(stateTime)) {
				currentFrame = caidaRepeatAnimacion.getKeyFrame(stateTime, true);
			}
			return currentFrame;
		case CAMINAR:
			return caminaAnimacion.getKeyFrame(stateTime, true);
		case DASH:
			return dashAnimacion.getKeyFrame(stateTime, true);
		case ATACAR:
			return atacarAnimacion.getKeyFrame(stateTime, true);
		case IDLE:
		default:
			return idleAnimacion.getKeyFrame(stateTime, true);
		}
	}
}
