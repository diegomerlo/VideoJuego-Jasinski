package com.slaythemall.io;

import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.InputProcessor;

public class Entradas implements InputProcessor {
	private boolean abajo = false, arriba = false, enter = false;
	private boolean izquierda = false, derecha = false, salto = false, dash = false;
	private boolean atacar = false; // Nueva variable para el ataque

	@Override
	public boolean keyDown(int keycode) { // CUANDO PRESIONA UNA TECLA
		if (keycode == Keys.UP) {
			arriba = true;
		}
		if (keycode == Keys.DOWN) {
			abajo = true;
		}
		if (keycode == Keys.ENTER) {
			enter = true;
		}
		if (keycode == Keys.LEFT) {
			izquierda = true;
		}
		if (keycode == Keys.RIGHT) {
			derecha = true;
		}
		if (keycode == Keys.C) {
			salto = true;
		}
		if (keycode == Keys.Z) {
			dash = true;
		}
		if (keycode == Keys.X) { // Nueva entrada para ataque
			atacar = true;
		}
		return false;
	}

	@Override
	public boolean keyUp(int keycode) { // CUANDO DEJA DE PRESIONAR LA TECLA
		if (keycode == Keys.UP) {
			arriba = false;
		}
		if (keycode == Keys.DOWN) {
			abajo = false;
		}
		if (keycode == Keys.ENTER) {
			enter = false;
		}
		if (keycode == Keys.LEFT) {
			izquierda = false;
		}
		if (keycode == Keys.RIGHT) {
			derecha = false;
		}
		if (keycode == Keys.C) {
			salto = false;
		}
		if (keycode == Keys.Z) {
			dash = false;
		}
		if (keycode == Keys.X) { // Nueva entrada para ataque
			atacar = false;
		}
		return false;
	}

	@Override
	public boolean keyTyped(char character) {
		return false;
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		return false;
	}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		return false;
	}

	@Override
	public boolean touchCancelled(int screenX, int screenY, int pointer, int button) {
		return false;
	}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		return false;
	}

	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		return false;
	}

	@Override
	public boolean scrolled(float amountX, float amountY) {
		return false;
	}

	public boolean isAbajo() {
		return abajo;
	}

	public boolean isArriba() {
		return arriba;
	}

	public boolean isEnter() {
		return enter;
	}

	public boolean isIzquierda() {
		return izquierda;
	}

	public boolean isDerecha() {
		return derecha;
	}

	public boolean isSalto() {
		return salto;
	}

	public void resetSalto() {
		salto = false;
	}

	public boolean isDash() {
		return dash;
	}

	public boolean isAtacar() { // Nuevo método para verificar el ataque
		return atacar;
	}

	public void resetAtacar() {
		atacar = false;
	}
	
	public void resetMoverDerecha() {
        derecha = false;
    }

    public void resetMoverIzquierda() {
        izquierda = false;
    }

    
    public void resetSaltar() {
        salto = false;
    }
    
    public void resetDash() {
        dash = false;
    }
	
}
