package com.slaythemall.mapas;

import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.MapObjects;
import com.badlogic.gdx.maps.objects.PolygonMapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.Fixture;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.Shape;
import com.slaythemall.objetos.Enemigo;
import com.slaythemall.objetos.Jugador;
import com.slaythemall.pantallas.PantallaJuego;
import com.slaythemall.utiles.BodyImpl;

import static com.slaythemall.utiles.Constantes.PPM;

public class TiledMaps {

	private TiledMap tiledMap;
	private PantallaJuego pantallaJuego;
	private Enemigo[] enemigos;
	private int enemigoIndex;

	public TiledMaps(PantallaJuego pantallaJuego) {
		this.pantallaJuego = pantallaJuego;
	}

	public OrthogonalTiledMapRenderer iniciarMapa() {
		tiledMap = new TmxMapLoader().load("mapas/mapa.tmx");
		int numEnemigos = contarEnemigos(tiledMap.getLayers().get("objetos").getObjects());
		enemigos = new Enemigo[numEnemigos];
		enemigoIndex = 0;
		parseMapObjects(tiledMap.getLayers().get("objetos").getObjects());
		pantallaJuego.setEnemigos(enemigos);
		return new OrthogonalTiledMapRenderer(tiledMap);
	}

	private int contarEnemigos(MapObjects mapObjects) {
		int count = 0;
		for (MapObject mapObject : mapObjects) {
			if (mapObject instanceof RectangleMapObject) {
				String rectangleName = mapObject.getName();
				if (rectangleName.equals("enemigo")) {
					count++;
				}
			}
		}
		return count;
	}

	private void parseMapObjects(MapObjects mapObjects) {
		for (MapObject mapObject : mapObjects) {
			if (mapObject instanceof PolygonMapObject) {
				crearCuerpoEstatico((PolygonMapObject) mapObject);
			}
			if (mapObject instanceof RectangleMapObject) {
				Rectangle rectangle = ((RectangleMapObject) mapObject).getRectangle();
				String rectangleName = mapObject.getName();
				if (rectangleName.equals("jugador")) {
					Body body = BodyImpl.createBody(rectangle.getX() + rectangle.getWidth() / 2,
							rectangle.getY() + rectangle.getHeight() / 2, rectangle.getWidth(), rectangle.getHeight(),
							false, pantallaJuego.getMundo());
					pantallaJuego.setJugador(new Jugador(rectangle.getWidth(), rectangle.getHeight(), body));
				}
				if (rectangleName.equals("sensorPies")) {
					BodyImpl.agregarFootSensor(pantallaJuego.getJugador().getBody(), rectangle);
				}
				if (rectangleName.equals("sensorEspada")) {
					Fixture sensorEspada = BodyImpl.agregarSensorEspada(pantallaJuego.getJugador().getBody(),
							rectangle);
					pantallaJuego.getJugador().setSensorEspada(sensorEspada);
					pantallaJuego.getJugador().setEspadaDimensiones(rectangle.getWidth(), rectangle.getHeight());
				}
				if (rectangleName.equals("enemigo")) {
					Body body = BodyImpl.createBody(rectangle.getX() + rectangle.getWidth() / 2,
							rectangle.getY() + rectangle.getHeight() / 2, rectangle.getWidth(), rectangle.getHeight(),
							true, pantallaJuego.getMundo());
					enemigos[enemigoIndex++] = new Enemigo(rectangle.getWidth(), rectangle.getHeight(), body);
				}
			}
		}
	}

	private void crearCuerpoEstatico(PolygonMapObject polygonMapObject) {
		BodyDef bodyDef = new BodyDef();
		bodyDef.type = BodyDef.BodyType.StaticBody;
		Body body = pantallaJuego.getMundo().createBody(bodyDef);
		Shape shape = createPolygonShape(polygonMapObject);
		body.createFixture(shape, 1000);
		shape.dispose();
	}

	private Shape createPolygonShape(PolygonMapObject polygonMapObject) {
		float[] vertices = polygonMapObject.getPolygon().getTransformedVertices();
		Vector2[] worldVertices = new Vector2[vertices.length / 2];
		for (int i = 0; i < vertices.length / 2; i++) {
			Vector2 current = new Vector2(vertices[i * 2] / PPM, vertices[i * 2 + 1] / PPM);
			worldVertices[i] = current;
		}
		PolygonShape shape = new PolygonShape();
		shape.set(worldVertices);
		return shape;
	}

	public void dispose() {
		if (tiledMap != null) {
			tiledMap.dispose();
		}
	}
}
