<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="fence_1" tilewidth="73" tileheight="19" tilecount="1" columns="1">
 <image source="fence_1.png" width="73" height="19"/>
</tileset>
